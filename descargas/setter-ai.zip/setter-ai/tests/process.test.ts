import { describe, expect, it, vi } from 'vitest';
import { encodePayload } from '../src/flows/engine.js';
import type { InstagramClient } from '../src/meta/client.js';
import { processInBackground, processWebhook } from '../src/process.js';
import { Sender } from '../src/sender.js';
import { STRANGER_ID, commentPayload, createMemoryStore, followFlow, messagePayload, postbackPayload } from './helpers.js';

function setup(flows = [followFlow()]) {
  const store = createMemoryStore();
  for (const flow of flows) store.flows.set(flow.id, flow);
  const client = {
    replyToComment: vi.fn().mockResolvedValue({ id: 'r1' }),
    sendPrivateReply: vi.fn().mockResolvedValue({ recipientId: STRANGER_ID, messageId: 'm1' }),
    sendMessage: vi.fn().mockResolvedValue({ recipientId: STRANGER_ID, messageId: 'm2' }),
    getFollowStatus: vi.fn().mockResolvedValue({ status: 'yes', detail: 'ok' }),
  } as unknown as InstagramClient & Record<string, ReturnType<typeof vi.fn>>;
  const sender = new Sender(
    { store, client, limits: { privateReplies: 100, publicReplies: 100, followUps: 100 }, delays: { commentMin: 0, commentMax: 0, followUpMin: 0, followUpMax: 0 }, sleep: async () => undefined },
    async (id) => store.flows.get(id),
  );
  return { store, client, sender, deps: { store, sender, random: () => 0 } };
}

describe('processWebhook con flujos', () => {
  it('comentario en el reel del flujo → respuesta pública + DM con botón', async () => {
    const { client, deps, store } = setup();
    await processWebhook(commentPayload(), deps);
    expect(client.replyToComment).toHaveBeenCalledWith('c-1', '¡Te escribí por DM! 📩');
    expect(client.sendPrivateReply).toHaveBeenCalledWith('c-1', expect.objectContaining({ attachment: expect.anything() }));
    expect(store.events[0]?.note).toContain('Reel n8n');
  });

  it('una sola vez por persona: el segundo comentario de la misma persona no recibe nada', async () => {
    const { client, deps, store } = setup();
    await processWebhook(commentPayload(), deps);
    await processWebhook(commentPayload({ id: 'c-2' }), deps);
    expect(client.sendPrivateReply).toHaveBeenCalledTimes(1);
    expect(store.events.some((e) => e.note.includes('ya recibió este flujo'))).toBe(true);
  });

  it('opción B: la misma persona en OTRO reel sí recibe el DM; en el mismo reel no', async () => {
    const { client, deps } = setup([followFlow({ trigger: { type: 'comment', mediaIds: 'all', keywords: [] } })]);
    await processWebhook(commentPayload(), deps);
    await processWebhook(commentPayload({ id: 'c-2' }), deps);
    await processWebhook(commentPayload({ id: 'c-3', media: { id: '18000000000000002' } }), deps);
    expect(client.sendPrivateReply).toHaveBeenCalledTimes(2);
  });

  it('pulsar "Lo quiero" → comprueba si sigue → manda el recurso', async () => {
    const { client, deps, sender } = setup();
    await processWebhook(postbackPayload(encodePayload('flow1', 'gate')), deps);
    await sender.idle();
    expect(client.getFollowStatus).toHaveBeenCalledWith(STRANGER_ID);
    expect(client.sendMessage).toHaveBeenCalledWith(
      STRANGER_ID,
      expect.objectContaining({ attachment: expect.objectContaining({ payload: expect.objectContaining({ text: 'Aquí lo tienes' }) }) }),
    );
  });

  it('comentario sin flujo, DMs, ecos y avisos "leído": solo se registran', async () => {
    const { client, deps, store } = setup([]);
    await processWebhook(commentPayload(), deps);
    await processWebhook(messagePayload('quiero info'), deps);
    await processWebhook(messagePayload('yo', { isEcho: true }), deps);
    await processWebhook({ entry: [{ id: '1', messaging: [{ read: { mid: 'x' }, timestamp: 1 }] }] }, deps);
    expect(client.replyToComment).not.toHaveBeenCalled();
    expect(client.sendMessage).not.toHaveBeenCalled();
    const notes = store.events.map((e) => e.note).join(' | ');
    expect(notes).toContain('ningún flujo');
    expect(notes).toContain('pasa al setter IA');
    expect(notes).toContain('eco');
    expect(notes).toContain('leído');
  });

  it('apunta de qué reel viene cada persona aunque ningún flujo salte', async () => {
    const { deps, store } = setup([]);
    await processWebhook(commentPayload(), deps);
    expect(store.contacts.get(STRANGER_ID)).toMatchObject({ username: 'cuenta_prueba', sourceMediaId: '18000000000000001' });
    expect(await store.reelStats()).toEqual([{ mediaId: '18000000000000001', comments: 1, people: 1, tagged: {} }]);
  });

  it('aviso vacío → "vacio"', async () => {
    const { deps, store } = setup();
    await processWebhook({ object: 'instagram', entry: [] }, deps);
    expect(store.events[0]?.kind).toBe('vacio');
  });
});

describe('processInBackground', () => {
  it('registra el error si algo falla dentro', async () => {
    const { deps, store } = setup();
    store.listFlows = vi.fn().mockRejectedValue(new Error('BD caída'));
    processInBackground(commentPayload(), deps);
    await vi.waitFor(() => expect(store.events.some((event) => event.kind === 'error')).toBe(true));
    expect(store.events.find((event) => event.kind === 'error')?.data).toEqual({ message: 'BD caída' });
  });
});

describe('B5: un evento que falla no hace perder los demás del mismo aviso', () => {
  it('apunta el error del primero y procesa el segundo', async () => {
    const { deps, store } = setup([]);
    const original = store.touchContact.bind(store);
    store.touchContact = vi.fn().mockRejectedValueOnce(new Error('la base falló un momento')).mockImplementation(original);
    const dm = (sender: string, mid: string) => ({ sender: { id: sender }, recipient: { id: '17841400000000001' }, timestamp: 1760000000000, message: { mid, text: 'hola' } });
    const payload = { object: 'instagram', entry: [{ id: '17841400000000001', time: 1760000000, messaging: [dm('900000000000001', 'm-1'), dm('900000000000002', 'm-2')] }] };
    await processWebhook(payload, deps);
    expect(store.events.some((e) => e.kind === 'error' && JSON.stringify(e.data).includes('la base falló un momento'))).toBe(true);
    expect(store.events.some((e) => e.kind === 'message' && JSON.stringify(e.data).includes('m-2'))).toBe(true);
  });
});

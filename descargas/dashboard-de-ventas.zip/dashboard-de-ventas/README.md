> **Dashboard de ventas · Sistema de Forja IA.** Sistema listo para replicar de la biblioteca [Forja IA](https://www.forjaia.com), adaptado por Juampi ([@juampiiacosta.ia](https://www.instagram.com/juampiiacosta.ia)). La guía paso a paso para instalarlo, publicarlo y vendérselo a un cliente está en [forjaia.com/sistemas](https://www.forjaia.com/sistemas).

# Forja IA · Dashboard de ventas

App web del equipo de ventas (Next.js + Supabase). Para el equipo de ventas de un negocio o una agencia.

- **Publicar:** [`docs/GUIA-PUBLICAR.md`](docs/GUIA-PUBLICAR.md)
- **Conectar GoHighLevel:** [`docs/GUIA-GHL.md`](docs/GUIA-GHL.md)
- **Manual de marca (colores, letras y estilo):** [`docs/manual-branding.md`](docs/manual-branding.md)

- **Conectar una web al dashboard (manual del equipo):** [`Team/Template-landing.md`](Team/Template-landing.md); para Claude, la skill `Team/skills/conectar-web-al-dashboard`.



import { NextResponse, type NextRequest } from "next/server";
import { createSessionClient } from "@/lib/supabase/server";

// Bloque 6 (el equipo, 11 oct 2026): aquí llega el enlace mágico que manda un administrador desde la ficha.
// Comprueba el código con Supabase, deja la sesión iniciada (cookies) y lleva a la app; si el enlace ya se usó o
// caducó, vuelve al login con un aviso. Fase 1 (12 oct): los accesos y «pide un enlace» llevan a crear la contraseña.
export async function GET(request: NextRequest) {
  const tokenHash = request.nextUrl.searchParams.get("token_hash");
  const tipo = request.nextUrl.searchParams.get("type");
  const siguiente = request.nextUrl.searchParams.get("siguiente");
  const destino = request.nextUrl.clone();
  destino.search = "";
  if (tokenHash && tipo === "magiclink") {
    const supabase = await createSessionClient();
    const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: "magiclink" });
    if (!error) {
      // Primero la pantalla de entrada con la marca (el equipo, 12 oct): ella lleva luego al destino
      destino.pathname = "/entrando";
      if (siguiente === "perfil") destino.search = "?siguiente=perfil";
      return NextResponse.redirect(destino);
    }
  }
  destino.pathname = "/login";
  destino.searchParams.set("error", "enlace");
  return NextResponse.redirect(destino);
}

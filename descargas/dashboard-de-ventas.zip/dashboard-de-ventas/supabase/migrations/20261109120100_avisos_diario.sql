-- Plan GHL F2 (el equipo, 8 nov 2026): email diario del CEO a las 8:00 de Madrid (info@tudominio.com).
-- Una fila por proyecto y fecha (de Madrid): si ya está, la segunda llamada del programador no manda otro email.
create table public.avisos_diario (
  proyecto_id uuid not null references public.proyectos (id) on delete cascade,
  fecha date not null,
  creado_en timestamptz not null default now(),
  primary key (proyecto_id, fecha)
);
alter table public.avisos_diario enable row level security;

-- Solo en la base de la nube (la de Forja), como la lectura de GHL (20261017120000_leer_ghl_cada_30s.sql).
-- Cada 15 min de 06:00 a 07:45 UTC: 4 intentos dentro de las 8:00-8:59 de Madrid (verano o invierno); la ruta solo manda
-- cuando en Madrid son las 8 y la fecha guardada evita repetir. Si un intento falla, el siguiente reintenta.
do $$
begin
  if exists (select 1 from public.proyectos where ghl_location_id = 'TU-LOCATION-ID-DE-GHL') then
    perform cron.schedule(
      'avisos-diario',
      '0,15,30,45 6,7 * * *',
      $job$
        select net.http_post(
          url := 'https://dashboard.tudominio.com/api/avisos/diario/' || p.id,
          headers := jsonb_build_object('Content-Type', 'application/json', 'x-forja-secreto', p.webhook_secreto),
          body := '{}'::jsonb,
          timeout_milliseconds := 60000
        )
        from public.proyectos p
        where p.ghl_location_id = 'TU-LOCATION-ID-DE-GHL'
      $job$
    );
  end if;
end $$;

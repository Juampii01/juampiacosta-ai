"use client";
import { useState, useCallback } from "react";
import { usePoll, timeAgo } from "@/components/usePoll";
import type { CompetitorAccount, CompetitorVideo } from "@/lib/competitor";
import { PLATFORM_LABEL, fmt, safeHref } from "@/lib/competitorUi";
import { PlatformIcon, PlatformHandle } from "@/components/PlatformIcon";
import { PageHeader } from "@/components/PageHeader";
import { Pagination } from "@/components/Pagination";
import {
  Eye, Heart, MessageCircle, Link2, Search, Film, RefreshCw, Flame, Lightbulb, Zap,
  PenLine, Mic, Trash2, Copy, Radar, Video, Settings, Bot, Clock, type LucideIcon,
} from "lucide-react";

// ─── helpers ─────────────────────────────────────────────────────────────────

// Fila de campo numérico con icono, usada por los 3 formularios de umbrales
// (añadir cuenta, escanear perfil, editar cuenta) — antes cada uno llevaba el
// emoji pegado al texto de la etiqueta.
type ThresholdField = [LucideIcon, string, number, (v: number) => void, number, number, number];
function ThresholdInputs({ fields }: { fields: ThresholdField[] }) {
  return (
    <>
      {fields.map(([Icon, label, val, setter, min, max, step]) => (
        <label key={label} className="text-xs text-zinc-400">
          <span className="mb-1 flex items-center gap-1.5"><Icon size={12} className="text-zinc-500" />{label}</span>
          <input type="number" min={min} max={max} step={step} value={val}
            onChange={(e) => setter(Number(e.target.value) || 0)}
            className="w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
      ))}
    </>
  );
}

const PLATFORMS: { id: string; label: string; placeholder: string; urlHint: string }[] = [
  { id: "tiktok",    label: "TikTok",    placeholder: "@creador",   urlHint: "https://www.tiktok.com/@usuario" },
  { id: "instagram", label: "Instagram", placeholder: "@creador",   urlHint: "https://www.instagram.com/usuario/" },
  { id: "youtube",   label: "YouTube",   placeholder: "@canal",     urlHint: "https://www.youtube.com/@canal" },
];

const STATUS_LABEL: Record<string, string> = {
  pending:      "Pendiente",
  transcribing: "Transcribiendo…",
  analysing:    "Analizando…",
  done:         "✓ Listo",
  error:        "Error",
  skipped:      "Omitido",
};
const STATUS_COLOR: Record<string, string> = {
  pending:      "bg-zinc-700 text-zinc-300",
  transcribing: "bg-amber-700 text-amber-100",
  analysing:    "bg-blue-700 text-blue-100",
  done:         "bg-emerald-700 text-white",
  error:        "bg-red-700 text-red-100",
  skipped:      "bg-zinc-700 text-zinc-400",
};

// ─── AddAccountForm ───────────────────────────────────────────────────────────

function AddAccountForm({ onAdded }: { onAdded: () => void }) {
  const [platform, setPlatform] = useState("tiktok");
  const [handle, setHandle]     = useState("");
  const [url, setUrl]           = useState("");
  const [minViews, setMinViews] = useState(50000);
  const [minComments, setMinComments] = useState(300);
  const [minLikes, setMinLikes] = useState(0);
  const [scanLimit, setScanLimit] = useState(20);
  const [intervalH, setIntervalH] = useState(6);
  const [saving, setSaving]     = useState(false);
  const [err, setErr]           = useState("");

  const pl = PLATFORMS.find((p) => p.id === platform)!;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      const res = await fetch("/api/competitors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform, handle, url, min_views: minViews, min_likes: minLikes, min_comments: minComments, scan_limit: scanLimit, check_interval_hours: intervalH }),
      });
      const json = await res.json() as { ok?: boolean; error?: string };
      if (!res.ok) { setErr(json.error ?? "Error"); return; }
      setHandle(""); setUrl(""); onAdded();
    } finally { setSaving(false); }
  }

  return (
    <form onSubmit={submit} className="rounded-lg border border-edge bg-panel p-4 space-y-4">
      <h3 className="font-semibold text-white text-sm">Añadir cuenta a espiar</h3>

      <div className="flex gap-2">
        {PLATFORMS.map((p) => (
          <button key={p.id} type="button" onClick={() => setPlatform(p.id)}
            className={`flex flex-1 items-center justify-center gap-2 rounded border px-3 py-2 text-sm font-medium transition ${platform === p.id ? "border-brand bg-brand/20 text-white" : "border-edge bg-ink text-zinc-400 hover:text-zinc-200"}`}>
            <PlatformIcon platform={p.id} size={16} /> {p.label}
          </button>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-sm text-zinc-300">
          Handle
          <input value={handle} onChange={(e) => setHandle(e.target.value)} placeholder={pl.placeholder} required
            className="mt-1 w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
        <label className="text-sm text-zinc-300">
          URL del perfil
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={pl.urlHint} required
            className="mt-1 w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase text-zinc-500">Umbrales mínimos para analizar un video</p>
        <div className="grid grid-cols-3 gap-3">
          <ThresholdInputs
            fields={[
              [Eye, "Vistas mín.", minViews, setMinViews, 0, 5_000_000, 10000],
              [Heart, "Likes mín.", minLikes, setMinLikes, 0, 500_000, 1000],
              [MessageCircle, "Comentarios mín.", minComments, setMinComments, 0, 50_000, 100],
            ]}
          />
        </div>
        <p className="mt-1 text-xs text-zinc-600">Solo se analizan videos que superen TODOS los umbrales configurados.</p>
      </div>

      <div className="flex items-end gap-4">
        <label className="text-sm text-zinc-300">
          Vídeos a revisar (máx.)
          <input type="number" min={1} max={100} value={scanLimit} onChange={(e) => setScanLimit(Math.max(1, Math.min(100, Number(e.target.value) || 20)))}
            className="mt-1 w-24 rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
        <label className="text-sm text-zinc-300">
          Revisar cada (horas)
          <input type="number" min={1} max={168} value={intervalH} onChange={(e) => setIntervalH(Math.max(1, Number(e.target.value) || 6))}
            className="mt-1 w-24 rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
        <button type="submit" disabled={saving}
          className="rounded bg-brand px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
          {saving ? "Guardando…" : "Añadir cuenta"}
        </button>
      </div>
      <p className="text-xs text-zinc-600">
        "Vídeos a revisar" son los más recientes que se piden al scrapear — los umbrales de arriba se aplican SOLO sobre esos, nunca miran más atrás en el historial del perfil.
      </p>

      {err && <p className="text-sm text-red-400">{err}</p>}
    </form>
  );
}

// ─── AddManualLinksForm ────────────────────────────────────────────────────────

// Detecta cuántos enlaces hay pegados (uno por línea, o separados por
// espacios/comas) según el mismo criterio con el que el backend los separa,
// solo para el contador en pantalla — el backend vuelve a hacer el split real.
function countLinks(text: string): number {
  return text.split(/[\s,]+/).map((s) => s.trim()).filter(Boolean).length;
}

// Pega uno o VARIOS enlaces de reel/video sueltos a la vez (no hace falta que
// sean de una cuenta que ya monitorices) y los manda directos a transcribir y
// adaptar — sin tener que darlos de alta como cuenta ni esperar al scrapeo
// periódico de un perfil entero.
function AddManualLinksForm({ onAdded }: { onAdded: () => void }) {
  const [text, setText] = useState("");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  const count = countLinks(text);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (count === 0) return;
    setSaving(true);
    setMsg("");
    try {
      const res = await fetch("/api/competitors/videos/manual", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      setMsg(json.ok ? json.message ?? "Hecho" : json.error ?? "Error");
      if (json.ok) {
        setText("");
        onAdded();
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-lg border border-edge bg-panel p-4 space-y-3">
      <h3 className="flex items-center gap-2 text-sm font-semibold text-white"><Link2 size={16} className="text-brand2" /> Añadir vídeos por enlace</h3>
      <p className="text-xs text-zinc-500">
        Pega uno o varios enlaces de Instagram/TikTok/YouTube (uno por línea, o separados por espacios) — se detectan
        solos y van directos a transcribir y adaptar, sin esperar al scrapeo de la cuenta.
      </p>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={"https://www.instagram.com/reel/XXXXX/\nhttps://www.tiktok.com/@user/video/1234567890"}
        rows={4}
        className="w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand"
      />
      <div className="flex items-center gap-3">
        <button
          type="submit"
          disabled={saving || count === 0}
          className="rounded bg-brand px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
        >
          {saving ? "Añadiendo…" : count > 0 ? `Añadir ${count} enlace(s)` : "Añadir enlaces"}
        </button>
        {msg && <span className="text-xs text-zinc-400">{msg}</span>}
      </div>
    </form>
  );
}

// ─── ScanProfileForm ────────────────────────────────────────────────────────

// Escaneo PUNTUAL de un perfil: mismos filtros que "Añadir cuenta a espiar",
// pero de una sola vez — no queda guardado como cuenta monitorizada (no hay
// que borrarlo después si solo querías echar un vistazo).
function ScanProfileForm({ onScanned }: { onScanned: () => void }) {
  const [platform, setPlatform] = useState("instagram");
  const [handle, setHandle] = useState("");
  const [url, setUrl] = useState("");
  const [minViews, setMinViews] = useState(50000);
  const [minLikes, setMinLikes] = useState(0);
  const [minComments, setMinComments] = useState(300);
  const [scanLimit, setScanLimit] = useState(20);
  const [scanning, setScanning] = useState(false);
  const [msg, setMsg] = useState("");

  const pl = PLATFORMS.find((p) => p.id === platform)!;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setScanning(true);
    setMsg("");
    try {
      const res = await fetch("/api/competitors/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform, handle, url, min_views: minViews, min_likes: minLikes, min_comments: minComments, scan_limit: scanLimit }),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      setMsg(json.ok ? json.message ?? "Hecho" : json.error ?? "Error");
      if (json.ok) onScanned();
    } finally {
      setScanning(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-lg border border-edge bg-panel p-4 space-y-4">
      <div>
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white"><Search size={16} className="text-brand2" /> Escanear un perfil ahora (sin guardarlo)</h3>
        <p className="mt-1 text-xs text-zinc-500">
          Un vistazo puntual con tus propios filtros — no se queda monitorizándose para siempre como "Añadir cuenta a espiar".
        </p>
      </div>

      <div className="flex gap-2">
        {PLATFORMS.map((p) => (
          <button key={p.id} type="button" onClick={() => setPlatform(p.id)}
            className={`flex flex-1 items-center justify-center gap-2 rounded border px-3 py-2 text-sm font-medium transition ${platform === p.id ? "border-brand bg-brand/20 text-white" : "border-edge bg-ink text-zinc-400 hover:text-zinc-200"}`}>
            <PlatformIcon platform={p.id} size={16} /> {p.label}
          </button>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-sm text-zinc-300">
          Handle
          <input value={handle} onChange={(e) => setHandle(e.target.value)} placeholder={pl.placeholder} required
            className="mt-1 w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
        <label className="text-sm text-zinc-300">
          URL del perfil
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={pl.urlHint} required
            className="mt-1 w-full rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase text-zinc-500">Umbrales mínimos (solo para este escaneo)</p>
        <div className="grid grid-cols-3 gap-3">
          <ThresholdInputs
            fields={[
              [Eye, "Vistas mín.", minViews, setMinViews, 0, 5_000_000, 10000],
              [Heart, "Likes mín.", minLikes, setMinLikes, 0, 500_000, 1000],
              [MessageCircle, "Comentarios mín.", minComments, setMinComments, 0, 50_000, 100],
            ]}
          />
        </div>
      </div>

      <div className="flex items-end gap-4">
        <label className="text-sm text-zinc-300">
          Vídeos a revisar (máx.)
          <input type="number" min={1} max={100} value={scanLimit} onChange={(e) => setScanLimit(Math.max(1, Math.min(100, Number(e.target.value) || 20)))}
            className="mt-1 w-24 rounded border border-edge bg-ink p-2 text-sm text-zinc-200 outline-none focus:border-brand" />
        </label>
        <button type="submit" disabled={scanning}
          className="inline-flex items-center gap-1.5 rounded bg-brand2 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
          {scanning ? "Escaneando…" : <><Search size={14} />Escanear ahora</>}
        </button>
        {msg && <span className="text-xs text-zinc-400">{msg}</span>}
      </div>
      <p className="text-xs text-zinc-600">
        Los umbrales de arriba se aplican SOLO sobre esos vídeos más recientes — no miran más atrás en el historial del perfil.
      </p>
    </form>
  );
}

// ─── AccountCard ──────────────────────────────────────────────────────────────

function AccountCard({ account, onChanged }: { account: CompetitorAccount; onChanged: () => void }) {
  const [deleting, setDeleting] = useState(false);
  const [editing, setEditing]   = useState(false);
  const [minV, setMinV] = useState(account.min_views);
  const [minL, setMinL] = useState(account.min_likes);
  const [minC, setMinC] = useState(account.min_comments);
  const [scanLim, setScanLim] = useState(account.scan_limit);
  const [intH, setIntH] = useState(account.check_interval_hours);

  async function toggleActive() {
    await fetch(`/api/competitors/${account.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !account.active }),
    });
    onChanged();
  }
  async function del() {
    if (!confirm(`¿Eliminar @${account.handle}? Se borrarán todos sus videos y guiones adaptados.`)) return;
    setDeleting(true);
    await fetch(`/api/competitors/${account.id}`, { method: "DELETE" });
    onChanged();
  }
  async function saveEdit() {
    await fetch(`/api/competitors/${account.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ min_views: minV, min_likes: minL, min_comments: minC, scan_limit: scanLim, check_interval_hours: intH }),
    });
    setEditing(false); onChanged();
  }

  return (
    <div className={`rounded-lg border bg-panel p-4 ${account.active ? "border-edge" : "border-zinc-800 opacity-60"}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <PlatformIcon platform={account.platform} size={18} />
            <span className="font-semibold text-white">@{account.handle}</span>
            {account.display_name && <span className="text-xs text-zinc-500">{account.display_name}</span>}
          </div>
          <a href={safeHref(account.url)} target="_blank" rel="noreferrer" className="mt-0.5 text-xs text-zinc-500 hover:text-brand">{account.url}</a>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-zinc-600">{account.video_count} videos</span>
          <button onClick={toggleActive}
            className={`relative h-5 w-9 rounded-full transition ${account.active ? "bg-emerald-600" : "bg-edge"}`}>
            <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition ${account.active ? "left-[18px]" : "left-0.5"}`} />
          </button>
          <button onClick={() => setEditing(!editing)} className="rounded border border-edge px-2 py-0.5 text-xs text-zinc-400 hover:text-zinc-200">
            {editing ? "Cancelar" : "Editar"}
          </button>
          <button onClick={del} disabled={deleting} className="rounded border border-red-900/50 px-2 py-0.5 text-xs text-red-400 hover:text-red-300 disabled:opacity-40">
            {deleting ? "…" : "Eliminar"}
          </button>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500">
        <span className="inline-flex items-center gap-1"><Eye size={12} />≥ {fmt(account.min_views)} vistas</span>
        <span className="inline-flex items-center gap-1"><Heart size={12} />≥ {fmt(account.min_likes)} likes</span>
        <span className="inline-flex items-center gap-1"><MessageCircle size={12} />≥ {fmt(account.min_comments)} coment.</span>
        <span className="inline-flex items-center gap-1"><Film size={12} />últimos {account.scan_limit}</span>
        <span className="inline-flex items-center gap-1"><RefreshCw size={12} />cada {account.check_interval_hours}h</span>
        {account.last_checked_at && <span>Última revisión: {timeAgo(account.last_checked_at)}</span>}
      </div>

      {editing && (
        <div className="mt-4 border-t border-edge/60 pt-4 space-y-3">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
            {(
              [
                [Eye, "Vistas mín.", minV, setMinV, 0, 5_000_000, 10000],
                [Heart, "Likes mín.", minL, setMinL, 0, 500_000, 1000],
                [MessageCircle, "Coment. mín.", minC, setMinC, 0, 50_000, 100],
                [Film, "Vídeos a revisar", scanLim, setScanLim, 1, 100, 1],
                [RefreshCw, "Intervalo (h)", intH, setIntH, 1, 168, 1],
              ] as ThresholdField[]
            ).map(([Icon, label, val, setter, min, max, step]) => (
              <label key={label} className="text-xs text-zinc-400">
                <span className="mb-1 flex items-center gap-1.5"><Icon size={12} className="text-zinc-500" />{label}</span>
                <input type="number" min={min} max={max} step={step} value={val}
                  onChange={(e) => setter(Number(e.target.value) || 0)}
                  className="w-full rounded border border-edge bg-ink p-1.5 text-sm text-zinc-200 outline-none focus:border-brand" />
              </label>
            ))}
          </div>
          <button onClick={saveEdit} className="rounded bg-brand px-4 py-1.5 text-sm font-semibold text-white">
            Guardar cambios
          </button>
        </div>
      )}
    </div>
  );
}

// ─── VideoCard ────────────────────────────────────────────────────────────────

function VideoCard({ video, selected, onToggleSelect, onDelete, deleting, onAnalyze, onTranscribe, transcribing }: {
  video: CompetitorVideo;
  selected: boolean;
  onToggleSelect: (id: number) => void;
  onDelete: (id: number) => void;
  deleting: number | null;
  onAnalyze: (id: number) => void;
  onTranscribe: (id: number) => void;
  transcribing: number | null;
}) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);

  async function copyTranscript() {
    if (!video.transcript) return;
    await navigator.clipboard.writeText(video.transcript);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  return (
    <article className={`rounded-lg border p-4 ${selected ? "border-brand bg-brand/5" : "border-edge bg-panel"}`}>
      <div className="flex items-start gap-3">
        <input
          type="checkbox"
          checked={selected}
          onChange={() => onToggleSelect(video.id)}
          className="mt-1.5 h-4 w-4 shrink-0 accent-brand"
          aria-label="Seleccionar video"
        />
        {video.thumbnail_url && (
          <img src={video.thumbnail_url} alt="" className="h-16 w-12 shrink-0 rounded object-cover" />
        )}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <a href={safeHref(video.video_url)} target="_blank" rel="noreferrer"
              className="font-medium text-white hover:text-brand line-clamp-2">
              {video.title ?? video.video_url}
            </a>
            <span className={`shrink-0 rounded px-2 py-0.5 text-xs font-semibold ${STATUS_COLOR[video.status] ?? STATUS_COLOR.pending}`}>
              {STATUS_LABEL[video.status] ?? video.status}
            </span>
          </div>

          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-zinc-500">
            <PlatformHandle platform={video.account_platform} handle={video.account_handle} />
            {video.views !== null && <span className="inline-flex items-center gap-1"><Eye size={12} />{fmt(video.views)}</span>}
            {video.likes !== null && <span className="inline-flex items-center gap-1"><Heart size={12} />{fmt(video.likes)}</span>}
            {video.comments !== null && <span className="inline-flex items-center gap-1"><MessageCircle size={12} />{fmt(video.comments)}</span>}
            {video.duration_sec && <span className="inline-flex items-center gap-1"><Clock size={12} />{Math.floor(video.duration_sec / 60)}:{String(video.duration_sec % 60).padStart(2, "0")}</span>}
            <span>{timeAgo(video.fetched_at)}</span>
          </div>

          {video.status === "done" && video.viral_score !== null && (
            <div className="mt-2 flex items-center gap-3 text-xs">
              <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 font-semibold ${video.viral_score >= 80 ? "bg-emerald-800 text-emerald-200" : video.viral_score >= 60 ? "bg-amber-800 text-amber-200" : "bg-zinc-700 text-zinc-300"}`}>
                <Flame size={13} />Viral {video.viral_score}/100
              </span>
              {video.hook_type && <span className="text-zinc-500">{video.hook_type}</span>}
            </div>
          )}

          {video.status === "done" && video.winning_idea && (
            <p className="mt-2 flex gap-1.5 text-sm text-zinc-300">
              <Lightbulb size={15} className="mt-0.5 shrink-0 text-zinc-500" />
              <span><span className="text-zinc-500">Idea:</span> {video.winning_idea}</span>
            </p>
          )}

          {video.status === "done" && video.hook && (
            <p className="mt-1 flex gap-1.5 text-sm text-zinc-400">
              <Zap size={15} className="mt-0.5 shrink-0 text-zinc-500" />
              <span><span className="text-zinc-500">Hook:</span> {video.hook}</span>
            </p>
          )}

          {video.status === "error" && video.error_msg && (
            <p className="mt-1 text-xs text-red-400">{video.error_msg}</p>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            {video.status === "done" && (
              <button onClick={() => setExpanded(!expanded)}
                className="rounded border border-edge px-2.5 py-1 text-xs text-zinc-400 hover:text-zinc-200">
                {expanded ? "Ocultar transcript" : "Ver transcript"}
              </button>
            )}
            {video.status === "done" && video.script_count > 0 && (
              <span className="rounded bg-brand2/20 px-2 py-0.5 text-xs text-brand2">
                {video.script_count} guion(es) generado(s)
              </span>
            )}
            {video.status === "done" && video.script_count === 0 && (
              <button onClick={() => onAnalyze(video.id)}
                className="inline-flex items-center gap-1.5 rounded bg-brand2 px-3 py-1 text-xs font-semibold text-white">
                <PenLine size={13} />Generar guion adaptado
              </button>
            )}
            {(video.status === "pending" || video.status === "error") && (
              <button
                onClick={() => onTranscribe(video.id)}
                disabled={transcribing === video.id}
                className="inline-flex items-center gap-1.5 rounded bg-zinc-700 px-3 py-1 text-xs font-semibold text-zinc-200 hover:bg-zinc-600 disabled:opacity-50"
              >
                {transcribing === video.id ? "Transcribiendo…" : <><Mic size={13} />Transcribir ahora</>}
              </button>
            )}
            <button
              onClick={() => onDelete(video.id)}
              disabled={deleting === video.id}
              className="ml-auto inline-flex items-center gap-1.5 rounded border border-red-900/60 px-2.5 py-1 text-xs text-red-400 hover:bg-red-950/40 disabled:opacity-50"
            >
              {deleting === video.id ? "Eliminando…" : <><Trash2 size={13} />Eliminar</>}
            </button>
          </div>

          {expanded && video.transcript && (
            <div className="mt-3 rounded border border-edge/60 bg-ink p-3">
              <div className="mb-2 flex justify-end">
                <button onClick={copyTranscript} className="inline-flex items-center gap-1.5 rounded border border-edge px-2 py-0.5 text-xs text-zinc-400 hover:border-brand hover:text-brand">
                  {copied ? "✓ Copiado" : <><Copy size={12} />Copiar transcripción</>}
                </button>
              </div>
              <p className="whitespace-pre-wrap text-xs leading-relaxed text-zinc-400">{video.transcript}</p>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}


// ─── Main page ────────────────────────────────────────────────────────────────

// Cada forma de meter contenido tiene su propia pestaña (antes los tres
// formularios iban apilados encima de la lista de cuentas y la página se
// hacía interminable): cuentas monitorizadas, escaneo puntual, enlaces
// sueltos, y al final los vídeos que resultan de cualquiera de las tres.
type Tab = "cuentas" | "escanear" | "enlaces" | "videos";

const VIDEOS_PAGE_SIZE = 20;

const VIDEO_STATUS_OPTIONS: { value: string; label: string }[] = [
  { value: "", label: "Todos los estados" },
  { value: "done", label: "✓ Analizados" },
  { value: "pending", label: "Pendientes" },
  { value: "transcribing", label: "Transcribiendo…" },
  { value: "analysing", label: "Analizando…" },
  { value: "error", label: "Error" },
];

export default function CompetenciaPage() {
  const [tab, setTab] = useState<Tab>("cuentas");
  const [accountFilter, setAccountFilter] = useState<number | undefined>(undefined);
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [videoPage, setVideoPage] = useState(1);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [selectingAll, setSelectingAll] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [analyzing, setAnalyzing] = useState<number | null>(null);
  const [analyzeMsg, setAnalyzeMsg] = useState("");
  const [transcribing, setTranscribing] = useState<number | null>(null);
  const [running, setRunning] = useState<"transcribe" | "full" | null>(null);
  const [polling, setPolling] = useState(false);
  const [pollMsg, setPollMsg] = useState("");

  const { data: accountsData, refresh: refreshAccounts } = usePoll<{ accounts: CompetitorAccount[] }>(
    "/api/competitors", 30000
  );
  const { data: videosData, refresh: refreshVideos } = usePoll<{
    videos: CompetitorVideo[];
    total: number;
    pages: number;
    counts: Record<string, number>;
  }>(
    `/api/competitors/videos?page=${videoPage}&pageSize=${VIDEOS_PAGE_SIZE}` +
      (accountFilter ? `&accountId=${accountFilter}` : "") +
      (statusFilter ? `&status=${statusFilter}` : ""),
    15000
  );

  const accounts = accountsData?.accounts ?? [];
  const videos = videosData?.videos ?? [];
  const videosTotal = videosData?.total ?? 0;
  const videosPages = videosData?.pages ?? 1;
  const statusCounts = videosData?.counts ?? {};

  function changeAccountFilter(id: number | undefined) {
    setAccountFilter(id);
    setVideoPage(1);
    setSelectedIds(new Set());
  }
  function changeStatusFilter(v: string) {
    setStatusFilter(v || undefined);
    setVideoPage(1);
    setSelectedIds(new Set());
  }
  // Cambiar de página YA NO borra la selección — antes tenías que
  // reseleccionar uno a uno en cada página porque esto la vaciaba en cada
  // click de "Siguiente".
  function changeVideoPage(p: number) {
    setVideoPage(p);
  }

  function toggleSelect(id: number) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleSelectPage() {
    setSelectedIds((prev) => {
      const allSelected = videos.length > 0 && videos.every((v) => prev.has(v.id));
      const next = new Set(prev);
      for (const v of videos) {
        if (allSelected) next.delete(v.id);
        else next.add(v.id);
      }
      return next;
    });
  }

  // Trae los ids de TODAS las páginas que cumplan el filtro actual (no solo
  // la visible) — sin esto, seleccionar "todos" solo alcanzaba a los ~20 de
  // la página actual y había que ir página a página marcando uno a uno.
  async function selectAllPages() {
    setSelectingAll(true);
    try {
      const params = new URLSearchParams({ idsOnly: "1" });
      if (accountFilter) params.set("accountId", String(accountFilter));
      if (statusFilter) params.set("status", statusFilter);
      const res = await fetch(`/api/competitors/videos?${params.toString()}`);
      const json = (await res.json()) as { ids?: number[] };
      setSelectedIds(new Set(json.ids ?? []));
    } finally {
      setSelectingAll(false);
    }
  }

  async function deleteVideoIds(ids: number[]): Promise<number> {
    const res = await fetch("/api/competitors/videos", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids }),
    });
    const json = (await res.json()) as { ok?: boolean; deleted?: number; error?: string };
    if (!json.ok) throw new Error(json.error ?? "Error al eliminar");
    return json.deleted ?? 0;
  }

  const handleDeleteOne = useCallback(async (id: number) => {
    if (!window.confirm("¿Eliminar este video? Se borrará también su transcripción, análisis y guiones adaptados. No se puede deshacer.")) return;
    setDeletingId(id); setAnalyzeMsg("");
    try {
      await deleteVideoIds([id]);
      setSelectedIds((prev) => { const next = new Set(prev); next.delete(id); return next; });
      refreshVideos();
    } catch (e) {
      setAnalyzeMsg((e as Error).message);
    } finally {
      setDeletingId(null);
    }
  }, [refreshVideos]);

  const handleDeleteSelected = useCallback(async () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    if (!window.confirm(`¿Eliminar ${ids.length} video(s) seleccionados? Se borrará también su transcripción, análisis y guiones adaptados. No se puede deshacer.`)) return;
    setBulkDeleting(true); setAnalyzeMsg("");
    try {
      const deleted = await deleteVideoIds(ids);
      setAnalyzeMsg(`✓ ${deleted} video(s) eliminados`);
      setSelectedIds(new Set());
      refreshVideos();
    } catch (e) {
      setAnalyzeMsg((e as Error).message);
    } finally {
      setBulkDeleting(false);
    }
  }, [selectedIds, refreshVideos]);

  const handlePoll = useCallback(async () => {
    setPolling(true); setPollMsg("");
    try {
      const res = await fetch("/api/competitors/poll", { method: "POST" });
      const json = await res.json() as { ok?: boolean; message?: string; inserted?: number; available?: boolean };
      setPollMsg(json.message ?? (json.ok ? "Hecho" : "Error"));
      if (json.inserted && json.inserted > 0) { setVideoPage(1); refreshVideos(); }
    } finally { setPolling(false); }
  }, [refreshVideos]);

  const handleRun = useCallback(async (mode: "transcribe" | "full") => {
    setRunning(mode); setAnalyzeMsg("");
    try {
      const res = await fetch("/api/competitors/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode }),
      });
      const json = await res.json() as { ok?: boolean; summary?: string; noKey?: boolean; error?: string };
      if (json.noKey) setAnalyzeMsg("Añade tu clave de OpenAI en Ajustes para transcribir.");
      else setAnalyzeMsg(json.summary ?? json.error ?? (json.ok ? "Hecho" : "Error"));
      refreshVideos();
    } finally { setRunning(null); }
  }, [refreshVideos]);

  const handleTranscribe = useCallback(async (videoId: number) => {
    setTranscribing(videoId); setAnalyzeMsg("");
    try {
      const res = await fetch(`/api/competitors/videos/${videoId}/transcribe`, { method: "POST" });
      const json = await res.json() as { ok?: boolean; error?: string };
      if (json.ok) { setAnalyzeMsg("✓ Transcripción completada"); refreshVideos(); }
      else setAnalyzeMsg(json.error ?? "Error al transcribir");
    } finally { setTranscribing(null); }
  }, [refreshVideos]);

  const handleAnalyze = useCallback(async (videoId: number) => {
    setAnalyzing(videoId); setAnalyzeMsg("");
    try {
      const res = await fetch(`/api/competitors/videos/${videoId}/adapt`, { method: "POST" });
      const json = await res.json() as { ok?: boolean; generated?: number; error?: string };
      if (json.ok) { setAnalyzeMsg(`✓ ${json.generated} guion(es) generados — revísalos en Adaptados`); refreshVideos(); }
      else setAnalyzeMsg(json.error ?? "Error al generar");
    } finally { setAnalyzing(null); }
  }, [refreshVideos]);

  const tabClass = (t: Tab) =>
    `-mb-px inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap border-b-2 px-4 py-2 text-sm font-medium transition ${
      tab === t ? "border-brand text-white" : "border-transparent text-zinc-400 hover:text-zinc-200"
    }`;

  // Recuentos sobre TODOS los videos (vía statusCounts), no solo la página
  // actual de 20 — así "Transcribir todos (N)" y el resumen reflejan el total
  // real aunque la lista visible esté paginada.
  const doneCount = statusCounts.done ?? 0;
  const pendingCount = statusCounts.pending ?? 0;
  const analysingCount = statusCounts.analysing ?? 0;

  return (
    <div>
      <PageHeader
        title="Competencia"
        subtitle="Vídeos virales de otros creadores que se transcriben y se adaptan a guiones tuyos. Tres formas de traerlos: cuentas monitorizadas, un escaneo puntual o enlaces sueltos."
      />
      {/* Tabs internos */}
      <div className="mb-5 flex gap-1 overflow-x-auto border-b border-edge">
        <button onClick={() => setTab("cuentas")} className={tabClass("cuentas")}>
          <Radar size={15} />Cuentas ({accounts.length})
        </button>
        <button onClick={() => setTab("escanear")} className={tabClass("escanear")}>
          <Search size={15} />Escanear perfil
        </button>
        <button onClick={() => setTab("enlaces")} className={tabClass("enlaces")}>
          <Link2 size={15} />Enlaces sueltos
        </button>
        <button onClick={() => setTab("videos")} className={tabClass("videos")}>
          <Video size={15} />Videos ({videosTotal})
        </button>
      </div>

      {analyzeMsg && (
        <div className="mb-4 rounded border border-emerald-800 bg-emerald-950/40 px-3 py-2 text-sm text-emerald-300">
          {analyzeMsg}
        </div>
      )}
      {pollMsg && (
        <div className="mb-4 rounded border border-blue-800 bg-blue-950/40 px-3 py-2 text-sm text-blue-300">
          {pollMsg}
        </div>
      )}

      {/* ── CUENTAS ── */}
      {tab === "cuentas" && (
        <div className="space-y-4">
          {accounts.length > 0 && (
            <div className="flex items-center gap-3">
              <button onClick={handlePoll} disabled={polling}
                className="inline-flex items-center gap-1.5 rounded bg-brand px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
                <RefreshCw size={14} className={polling ? "animate-spin" : ""} />{polling ? "Buscando videos…" : "Descubrir ahora"}
              </button>
              <span className="text-xs text-zinc-500">
                Busca videos nuevos en todas las cuentas que tengas programadas para revisión.
              </span>
            </div>
          )}
          <AddAccountForm onAdded={refreshAccounts} />

          {accounts.length === 0 ? (
            <div className="rounded-lg border border-dashed border-edge p-8 text-center text-zinc-500">
              <Radar size={28} className="mx-auto mb-2 text-zinc-600" />
              <p className="text-sm">Añade tus primeras cuentas de competencia arriba.</p>
              <p className="mt-1 text-xs text-zinc-600">
                El sistema revisará sus videos automáticamente y filtrará los que superen tus umbrales.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {accounts.map((a) => (
                <AccountCard key={a.id} account={a} onChanged={refreshAccounts} />
              ))}
            </div>
          )}

          {accounts.length > 0 && (
            <div className="rounded-lg border border-amber-900/40 bg-amber-950/20 p-4 text-sm text-amber-300/80">
              <p className="mb-1 flex items-center gap-1.5 font-semibold"><Settings size={14} />Para activar el descubrimiento automático</p>
              <ul className="text-xs text-amber-400/70 space-y-1 list-disc pl-4">
                <li className="flex items-start gap-1.5">
                  <PlatformIcon platform="instagram" size={13} className="mt-0.5" />
                  <span><b>Instagram:</b> añade tu <b>token de Apify</b> en Ajustes (scraping seguro desde
                  servidor; no necesita yt-dlp).</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="mt-0.5 flex gap-1"><PlatformIcon platform="youtube" size={13} /><PlatformIcon platform="tiktok" size={13} /></span>
                  <span><b>YouTube / TikTok:</b> requieren <code className="bg-amber-950/60 px-1 rounded">yt-dlp</code> + <code className="bg-amber-950/60 px-1 rounded">ffmpeg</code> en el servidor{" "}
                  (<code className="bg-amber-950/60 px-1 rounded">brew install yt-dlp ffmpeg</code> en macOS).</span>
                </li>
                <li>Para las transcripciones, añade tu <b>clave de OpenAI</b> en Ajustes.</li>
              </ul>
            </div>
          )}
        </div>
      )}

      {/* ── ESCANEO PUNTUAL ── */}
      {tab === "escanear" && (
        <ScanProfileForm
          onScanned={() => {
            setTab("videos");
            refreshVideos();
          }}
        />
      )}

      {/* ── ENLACES SUELTOS ── */}
      {tab === "enlaces" && (
        <AddManualLinksForm
          onAdded={() => {
            setTab("videos");
            refreshVideos();
          }}
        />
      )}

      {/* ── VIDEOS ── */}
      {tab === "videos" && (
        <div className="space-y-4">
          {/* filtros y acciones batch */}
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={handlePoll} disabled={polling || !!running}
              className="inline-flex items-center gap-1.5 rounded bg-brand px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-50">
              <RefreshCw size={14} className={polling ? "animate-spin" : ""} />{polling ? "Buscando…" : "Descubrir"}
            </button>

            {pendingCount > 0 && (
              <button onClick={() => handleRun("transcribe")} disabled={!!running || !!transcribing}
                className="inline-flex items-center gap-1.5 rounded bg-indigo-700 px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-50">
                {running === "transcribe" ? "Transcribiendo…" : <><Mic size={14} />Transcribir todos ({pendingCount})</>}
              </button>
            )}

            {(pendingCount > 0 || analysingCount > 0) && (
              <button onClick={() => handleRun("full")} disabled={!!running || !!transcribing}
                className="inline-flex items-center gap-1.5 rounded bg-emerald-700 px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-50">
                {running === "full" ? "Procesando… (puede tardar unos minutos)" : <><Bot size={14} />Auto-pilot: transcribir + analizar + guiones</>}
              </button>
            )}

            <select value={accountFilter ?? ""} onChange={(e) => changeAccountFilter(e.target.value ? Number(e.target.value) : undefined)}
              className="rounded border border-edge bg-panel px-3 py-1.5 text-sm text-zinc-200">
              <option value="">Todas las cuentas</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>[{PLATFORM_LABEL[a.platform] ?? a.platform}] @{a.handle}</option>
              ))}
            </select>

            <select value={statusFilter ?? ""} onChange={(e) => changeStatusFilter(e.target.value)}
              className="rounded border border-edge bg-panel px-3 py-1.5 text-sm text-zinc-200">
              {VIDEO_STATUS_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3 text-xs text-zinc-500">
            <span>{videosTotal} videos · {doneCount} analizados · {pendingCount} pendientes</span>
            {(analyzing !== null || running) && (
              <span className="text-amber-400">Procesando… puede tardar unos minutos</span>
            )}
          </div>

          {/* selección y borrado */}
          {videos.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 rounded border border-edge bg-panel px-3 py-2 text-xs">
              <label className="flex items-center gap-2 text-zinc-400">
                <input
                  type="checkbox"
                  checked={videos.length > 0 && videos.every((v) => selectedIds.has(v.id))}
                  onChange={toggleSelectPage}
                  className="h-4 w-4 accent-brand"
                />
                Seleccionar página ({videos.length})
              </label>
              <button
                onClick={selectAllPages}
                disabled={selectingAll}
                className="text-brand hover:underline disabled:opacity-50"
              >
                {selectingAll ? "Seleccionando…" : `Seleccionar TODOS (${videosTotal})`}
              </button>
              {selectedIds.size > 0 && (
                <>
                  <span className="text-zinc-500">{selectedIds.size} seleccionado(s)</span>
                  <button
                    onClick={handleDeleteSelected}
                    disabled={bulkDeleting}
                    className="ml-auto inline-flex items-center gap-1.5 rounded bg-red-800 px-3 py-1 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
                  >
                    {bulkDeleting ? "Eliminando…" : <><Trash2 size={13} />Eliminar seleccionados ({selectedIds.size})</>}
                  </button>
                  <button onClick={() => setSelectedIds(new Set())} className="text-zinc-500 hover:text-zinc-300">
                    cancelar
                  </button>
                </>
              )}
            </div>
          )}

          {videos.length === 0 ? (
            <div className="rounded-lg border border-dashed border-edge p-8 text-center text-zinc-500">
              <Video size={28} className="mx-auto mb-2 text-zinc-600" />
              <p className="text-sm">
                {statusFilter || accountFilter ? "No hay videos con este filtro." : "No hay videos todavía."}
              </p>
              <p className="mt-1 text-xs text-zinc-600">
                Los videos aparecerán aquí una vez que el worker descubra contenido viral de tus cuentas espiadas.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {videos.map((v) => (
                <VideoCard key={v.id} video={v}
                  selected={selectedIds.has(v.id)}
                  onToggleSelect={toggleSelect}
                  onDelete={handleDeleteOne}
                  deleting={deletingId}
                  onAnalyze={handleAnalyze}
                  onTranscribe={handleTranscribe}
                  transcribing={transcribing} />
              ))}
            </div>
          )}

          <Pagination page={videoPage} pages={videosPages} onChange={changeVideoPage} />
        </div>
      )}

    </div>
  );
}

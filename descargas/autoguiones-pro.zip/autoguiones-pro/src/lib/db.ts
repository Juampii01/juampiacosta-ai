import { DatabaseSync, type StatementSync } from "node:sqlite";
import { mkdirSync, existsSync, accessSync, constants } from "node:fs";
import { dirname, join } from "node:path";

// Resuelve dónde vive la BD, priorizando un DISCO PERSISTENTE para que las
// cuentas/guiones NO se borren en cada deploy:
//   1) DB_PATH si está definido (lo ideal en producción).
//   2) /data o /var/data si existe y es escribible (convención de discos en
//      Render/Railway) → auto-detección por si olvidaste poner DB_PATH.
//   3) ./data/app.db (solo local; en un host serverless esto NO persiste).
function resolveDbPath(): { path: string; persistent: boolean; reason: string } {
  const explicit = process.env.DB_PATH?.trim();
  if (explicit) return { path: explicit, persistent: true, reason: "DB_PATH" };

  for (const mount of ["/data", "/var/data"]) {
    try {
      if (existsSync(mount)) {
        accessSync(mount, constants.W_OK);
        return { path: join(mount, "app.db"), persistent: true, reason: `disco en ${mount}` };
      }
    } catch {
      /* no escribible: probar siguiente */
    }
  }
  return { path: join(process.cwd(), "data", "app.db"), persistent: false, reason: "local (efímero)" };
}

const RESOLVED = resolveDbPath();
const DB_PATH = RESOLVED.path;

type Stmt = StatementSync;

// Conexión PEREZOSA: no abrimos la BD al importar el módulo (importante para que
// `next build` no la abra durante "collect page data" y choque con otros procesos).
// Se abre y se crea el esquema en el primer uso real (request/worker).
let _raw: DatabaseSync | null = null;
function getRaw(): DatabaseSync {
  if (_raw) return _raw;
  mkdirSync(dirname(DB_PATH), { recursive: true });
  console.log(`[db] Base de datos: ${DB_PATH} (${RESOLVED.reason})`);
  if (!RESOLVED.persistent && process.env.NODE_ENV === "production") {
    console.warn(
      "[db] ⚠ AVISO: la BD NO está en un disco persistente. En cada deploy se " +
        "BORRARÁN las cuentas. Monta un disco (p.ej. en /data) y pon DB_PATH=/data/app.db."
    );
  }
  const r = new DatabaseSync(DB_PATH);
  r.exec("PRAGMA journal_mode = WAL;");
  r.exec("PRAGMA busy_timeout = 5000;");
  initSchema(r);
  _raw = r;
  return r;
}

export function dbInfo(): { path: string; persistent: boolean; reason: string } {
  return { path: DB_PATH, persistent: RESOLVED.persistent, reason: RESOLVED.reason };
}

// Adaptador fino que expone el subconjunto de la API de better-sqlite3 que usamos.
export const db = {
  exec: (sql: string): void => getRaw().exec(sql),
  prepare: (sql: string): Stmt => {
    const s = getRaw().prepare(sql);
    // Permite pasar parámetros nombrados con claves "desnudas" (sin @/:/$).
    try {
      (s as unknown as { setAllowBareNamedParameters?: (b: boolean) => void })
        .setAllowBareNamedParameters?.(true);
    } catch {
      /* versiones antiguas */
    }
    return s;
  },
  // Envuelve una función en una transacción. Devuelve una función que la ejecuta.
  transaction<A>(fn: (arg: A) => void): (arg: A) => void {
    return (arg: A) => {
      const r = getRaw();
      r.exec("BEGIN");
      try {
        fn(arg);
        r.exec("COMMIT");
      } catch (e) {
        r.exec("ROLLBACK");
        throw e;
      }
    };
  },
};

function initSchema(r: DatabaseSync): void {
  r.exec(`
-- ===== Cuentas y sesiones (auth nativa sobre SQLite) =====
CREATE TABLE IF NOT EXISTS users (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  email          TEXT NOT NULL UNIQUE,
  name           TEXT,
  password_hash  TEXT NOT NULL,
  created_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token       TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL,
  expires_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- Ajustes por usuario (incluida su clave de Anthropic y los parámetros de generación).
CREATE TABLE IF NOT EXISTS user_settings (
  user_id                INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  anthropic_key          TEXT NOT NULL DEFAULT '',
  gen_model              TEXT NOT NULL DEFAULT 'claude-opus-4-8',
  auto_generate          INTEGER NOT NULL DEFAULT 1,
  gen_relevance_threshold INTEGER NOT NULL DEFAULT 80,
  news_min_relevance     INTEGER NOT NULL DEFAULT 55,
  max_scripts_per_day    INTEGER NOT NULL DEFAULT 15,
  max_daily_usd          REAL NOT NULL DEFAULT 5,
  formats                TEXT NOT NULL DEFAULT 'reel,youtube',
  window_minutes         INTEGER NOT NULL DEFAULT 0,   -- 0 = sin ventana (siempre activo)
  window_interval_hours  INTEGER NOT NULL DEFAULT 0,   -- 0 = sin ventana (siempre activo)
  updated_at             TEXT
);

-- ===== Noticias: pool GLOBAL compartido (se trae una sola vez) =====
CREATE TABLE IF NOT EXISTS articles (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  source        TEXT NOT NULL,
  url           TEXT NOT NULL UNIQUE,
  title         TEXT NOT NULL,
  summary       TEXT,
  published_at  TEXT,
  fetched_at    TEXT NOT NULL,
  raw_json      TEXT
);
CREATE INDEX IF NOT EXISTS idx_articles_fetched ON articles(fetched_at DESC);

-- ===== Todo lo demás es PRIVADO por usuario =====
CREATE TABLE IF NOT EXISTS classifications (
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id      INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  relevance       INTEGER NOT NULL,
  category        TEXT,
  business_angle  TEXT,
  actuality_link  TEXT,
  model           TEXT,
  created_at      TEXT NOT NULL,
  PRIMARY KEY (user_id, article_id)
);
CREATE INDEX IF NOT EXISTS idx_class_relevance ON classifications(user_id, relevance DESC);

CREATE TABLE IF NOT EXISTS scripts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id  INTEGER REFERENCES articles(id) ON DELETE SET NULL,
  format      TEXT NOT NULL,
  title       TEXT,
  hook        TEXT,
  body        TEXT,
  cta         TEXT,
  status      TEXT NOT NULL DEFAULT 'borrador',
  model       TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scripts_user ON scripts(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS critiques (
  script_id    INTEGER PRIMARY KEY REFERENCES scripts(id) ON DELETE CASCADE,
  score        REAL NOT NULL,
  tone_match   REAL,
  strengths    TEXT,
  weaknesses   TEXT,
  improvements TEXT,
  model        TEXT,
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usage_log (
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day            TEXT NOT NULL,
  calls          INTEGER NOT NULL DEFAULT 0,
  input_tokens   INTEGER NOT NULL DEFAULT 0,
  output_tokens  INTEGER NOT NULL DEFAULT 0,
  cost_usd       REAL NOT NULL DEFAULT 0,
  scripts_count  INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);

CREATE TABLE IF NOT EXISTS gen_queue (
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id  INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  enqueued_at TEXT NOT NULL,
  done        INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, article_id)
);

CREATE TABLE IF NOT EXISTS classify_batches (
  batch_id    TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'in_progress'
);

CREATE TABLE IF NOT EXISTS brand_docs (
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,
  content     TEXT,
  updated_at  TEXT,
  PRIMARY KEY (user_id, kind)
);

CREATE TABLE IF NOT EXISTS swipe_files (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  platform    TEXT,
  author      TEXT,
  content     TEXT NOT NULL,
  why         TEXT,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS script_metrics (
  script_id      INTEGER PRIMARY KEY REFERENCES scripts(id) ON DELETE CASCADE,
  views          INTEGER NOT NULL DEFAULT 0,
  likes          INTEGER NOT NULL DEFAULT 0,
  comments       INTEGER NOT NULL DEFAULT 0,
  shares         INTEGER NOT NULL DEFAULT 0,
  new_followers  INTEGER NOT NULL DEFAULT 0,
  published_at   TEXT,
  notes          TEXT,
  updated_at     TEXT
);

-- ===== ESPIONAJE DE COMPETENCIA =====
CREATE TABLE IF NOT EXISTS competitor_accounts (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id              INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform             TEXT NOT NULL,
  handle               TEXT NOT NULL,
  url                  TEXT NOT NULL,
  display_name         TEXT,
  active               INTEGER NOT NULL DEFAULT 1,
  min_views            INTEGER NOT NULL DEFAULT 50000,
  min_likes            INTEGER NOT NULL DEFAULT 0,
  min_comments         INTEGER NOT NULL DEFAULT 300,
  check_interval_hours INTEGER NOT NULL DEFAULT 6,
  last_checked_at      TEXT,
  created_at           TEXT NOT NULL,
  UNIQUE(user_id, platform, handle)
);
CREATE INDEX IF NOT EXISTS idx_comp_accounts_user ON competitor_accounts(user_id);

CREATE TABLE IF NOT EXISTS competitor_videos (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id    INTEGER NOT NULL REFERENCES competitor_accounts(id) ON DELETE CASCADE,
  video_url     TEXT NOT NULL UNIQUE,
  video_id      TEXT,
  title         TEXT,
  description   TEXT,
  thumbnail_url TEXT,
  views         INTEGER,
  likes         INTEGER,
  comments      INTEGER,
  shares        INTEGER,
  duration_sec  INTEGER,
  published_at  TEXT,
  fetched_at    TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'pending',
  error_msg     TEXT
);
CREATE INDEX IF NOT EXISTS idx_comp_videos_account ON competitor_videos(account_id, fetched_at DESC);
CREATE INDEX IF NOT EXISTS idx_comp_videos_status  ON competitor_videos(status);

CREATE TABLE IF NOT EXISTS competitor_transcripts (
  video_id    INTEGER PRIMARY KEY REFERENCES competitor_videos(id) ON DELETE CASCADE,
  text        TEXT NOT NULL,
  language    TEXT,
  model       TEXT,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS competitor_analyses (
  video_id          INTEGER PRIMARY KEY REFERENCES competitor_videos(id) ON DELETE CASCADE,
  hook              TEXT,
  hook_type         TEXT,
  winning_idea      TEXT,
  curiosity_gap     TEXT,
  viral_pattern     TEXT,
  why_it_works      TEXT,
  content_structure TEXT,
  viral_score       INTEGER,
  model             TEXT,
  created_at        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS competitor_scripts (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id         INTEGER NOT NULL REFERENCES competitor_videos(id) ON DELETE CASCADE,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  format           TEXT NOT NULL,
  title            TEXT,
  hook             TEXT,
  body             TEXT,
  cta              TEXT,
  adaptation_notes TEXT,
  status           TEXT NOT NULL DEFAULT 'borrador',
  model            TEXT,
  created_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_comp_scripts_user  ON competitor_scripts(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comp_scripts_video ON competitor_scripts(video_id);

-- ===== DRIVE: carpetas + audios/video subidos, vinculables a un guion =====
CREATE TABLE IF NOT EXISTS drive_folders (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  parent_id  INTEGER REFERENCES drive_folders(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_drive_folders_parent ON drive_folders(user_id, parent_id);

CREATE TABLE IF NOT EXISTS drive_files (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  folder_id      INTEGER REFERENCES drive_folders(id) ON DELETE CASCADE,
  original_name  TEXT NOT NULL,
  path           TEXT NOT NULL,
  mime           TEXT NOT NULL,
  size           INTEGER NOT NULL,
  kind           TEXT NOT NULL DEFAULT 'video',
  status         TEXT NOT NULL DEFAULT 'por_grabar',
  scheduled_date TEXT,
  linked_type    TEXT,
  linked_id      INTEGER,
  notes          TEXT,
  uploaded_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_drive_files_folder ON drive_files(user_id, folder_id);
CREATE INDEX IF NOT EXISTS idx_drive_files_sched   ON drive_files(user_id, scheduled_date);

-- ===== CALENDARIO: una publicación = guion + audio (tu voz) + video (ya
-- clonado con IA) + fecha + estado, todo junto y creable de un tirón desde
-- el "+" del día en /calendario. Es un objeto propio (no un drive_file más)
-- porque necesita DOS archivos a la vez (audio Y video), cosa que un solo
-- drive_file no puede representar.
CREATE TABLE IF NOT EXISTS content_items (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id              INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  linked_type          TEXT,
  linked_id            INTEGER,
  title                TEXT,
  status               TEXT NOT NULL DEFAULT 'por_grabar',
  scheduled_date       TEXT NOT NULL,
  audio_path           TEXT,
  audio_original_name  TEXT,
  audio_mime           TEXT,
  audio_size           INTEGER,
  video_path           TEXT,
  video_original_name  TEXT,
  video_mime           TEXT,
  video_size           INTEGER,
  notes                TEXT,
  created_at           TEXT NOT NULL,
  updated_at           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_content_items_date ON content_items(user_id, scheduled_date);

-- Enlaces públicos para compartir guiones sueltos con un influencer/editor sin
-- que necesite cuenta: un token abre una página de solo lectura con el texto
-- de los guiones elegidos. "items" guarda [{type, id}] como JSON porque el
-- número de guiones por enlace es variable (no tiene sentido una tabla puente).
CREATE TABLE IF NOT EXISTS shared_links (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token      TEXT NOT NULL UNIQUE,
  title      TEXT,
  items      TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shared_links_token ON shared_links(token);
CREATE INDEX IF NOT EXISTS idx_shared_links_user  ON shared_links(user_id, created_at DESC);

-- Fila única: último latido del worker de fondo. Si esto deja de actualizarse,
-- el worker está muerto aunque la web siga respondiendo con normalidad.
CREATE TABLE IF NOT EXISTS worker_heartbeat (
  id                    INTEGER PRIMARY KEY CHECK (id = 1),
  last_run_at           TEXT NOT NULL,
  last_ok               INTEGER NOT NULL,
  last_error            TEXT,
  fetched               INTEGER NOT NULL DEFAULT 0,
  inserted              INTEGER NOT NULL DEFAULT 0,
  classified            INTEGER NOT NULL DEFAULT 0,
  generated             INTEGER NOT NULL DEFAULT 0,
  competitor_ok         INTEGER NOT NULL DEFAULT 1,
  competitor_checked    INTEGER NOT NULL DEFAULT 0,
  competitor_inserted   INTEGER NOT NULL DEFAULT 0,
  transcribed_processed INTEGER NOT NULL DEFAULT 0,
  transcribed_errors    INTEGER NOT NULL DEFAULT 0
);

-- ===== CLONACIÓN CON IA (HeyGen): un guion aprobado -> un vídeo con tu avatar =====
-- Una fila por guion (script o competitor_script) que ha entrado alguna vez al
-- pipeline de HeyGen. UNIQUE(source_type, source_id) porque un mismo guion no
-- debe generar dos vídeos en paralelo si el ciclo automático lo revisa dos veces.
CREATE TABLE IF NOT EXISTS heygen_renders (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_type     TEXT NOT NULL,   -- 'script' | 'competitor_script'
  source_id       INTEGER NOT NULL,
  heygen_video_id TEXT,
  status          TEXT NOT NULL DEFAULT 'processing', -- processing|completed|error
  video_path      TEXT,
  duration_sec    REAL,
  cost_usd        REAL,
  error_msg       TEXT,
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL,
  UNIQUE(source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_heygen_renders_user   ON heygen_renders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_heygen_renders_status ON heygen_renders(status);

-- Gasto de HeyGen por día y usuario, separado de usage_log (que es solo Anthropic)
-- porque tiene su propio tope diario configurable en Ajustes.
CREATE TABLE IF NOT EXISTS heygen_usage_log (
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day         TEXT NOT NULL,
  videos      INTEGER NOT NULL DEFAULT 0,
  seconds     REAL NOT NULL DEFAULT 0,
  cost_usd    REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);
`);

  // Columnas añadidas en versiones posteriores. Usamos PRAGMA para no depender
  // de la sintaxis "IF NOT EXISTS" de ALTER TABLE (no disponible en SQLite < 3.37).
  const cols = r.prepare(`PRAGMA table_info(user_settings)`).all() as { name: string }[];
  if (!cols.some((c) => c.name === "openai_key")) {
    r.exec(`ALTER TABLE user_settings ADD COLUMN openai_key TEXT NOT NULL DEFAULT ''`);
    console.log("[db] columna openai_key añadida a user_settings");
  }
  if (!cols.some((c) => c.name === "apify_token")) {
    r.exec(`ALTER TABLE user_settings ADD COLUMN apify_token TEXT NOT NULL DEFAULT ''`);
    console.log("[db] columna apify_token añadida a user_settings");
  }
  // Tope DIARIO (medianoche UTC) de guiones de competencia adaptados, por
  // usuario. Mismo criterio que window_minutes/window_interval_hours: 0 = sin tope.
  if (!cols.some((c) => c.name === "competitor_adapt_limit")) {
    r.exec(`ALTER TABLE user_settings ADD COLUMN competitor_adapt_limit INTEGER NOT NULL DEFAULT 3`);
    console.log("[db] columna competitor_adapt_limit añadida a user_settings");
  }

  // is_manual: distingue la cuenta especial "enlaces sueltos" (una por
  // usuario y plataforma, creada sola la primera vez que se pega un enlace a
  // mano) de las cuentas reales que el usuario monitoriza — para poder
  // excluirla de la lista de "cuentas" en pantalla sin tocar el resto del
  // pipeline (sus vídeos se ven igual en /competencia).
  const acols = r.prepare(`PRAGMA table_info(competitor_accounts)`).all() as { name: string }[];
  if (!acols.some((c) => c.name === "is_manual")) {
    r.exec(`ALTER TABLE competitor_accounts ADD COLUMN is_manual INTEGER NOT NULL DEFAULT 0`);
    console.log("[db] columna is_manual añadida a competitor_accounts");
  }

  // scan_limit: cuántos vídeos MÁS RECIENTES del perfil se piden a
  // Apify/yt-dlp antes de aplicar los umbrales de vistas/likes/comentarios —
  // antes estaba fijo en 20 en el código; un vídeo viral más viejo que los
  // últimos `scan_limit` posts del perfil nunca llega ni a mirarse, así que
  // hace falta poder subirlo. 20 de default para no cambiar el comportamiento
  // de las cuentas ya existentes.
  if (!acols.some((c) => c.name === "scan_limit")) {
    r.exec(`ALTER TABLE competitor_accounts ADD COLUMN scan_limit INTEGER NOT NULL DEFAULT 20`);
    console.log("[db] columna scan_limit añadida a competitor_accounts");
  }

  // media_url: URL directa del mp4 (Instagram vía Apify) para descargar el audio
  // sin yt-dlp. Las URLs de Instagram caducan, por eso se transcriben en el mismo ciclo.
  const vcols = r.prepare(`PRAGMA table_info(competitor_videos)`).all() as { name: string }[];
  if (!vcols.some((c) => c.name === "media_url")) {
    r.exec(`ALTER TABLE competitor_videos ADD COLUMN media_url TEXT`);
    console.log("[db] columna media_url añadida a competitor_videos");
  }

  // puente: transición del hook literal al vehículo único del creador.
  const scols = r.prepare(`PRAGMA table_info(competitor_scripts)`).all() as { name: string }[];
  if (!scols.some((c) => c.name === "puente")) {
    r.exec(`ALTER TABLE competitor_scripts ADD COLUMN puente TEXT`);
    console.log("[db] columna puente añadida a competitor_scripts");
  }

  // Audio/video que el usuario sube de sí mismo leyendo el guion, para que
  // el editor lo use como referencia/clonación con IA.
  for (const [col, def] of [
    ["media_path", "TEXT"],
    ["media_original_name", "TEXT"],
    ["media_mime", "TEXT"],
    ["media_size", "INTEGER"],
    ["media_uploaded_at", "TEXT"],
  ] as const) {
    if (!scols.some((c) => c.name === col)) {
      r.exec(`ALTER TABLE competitor_scripts ADD COLUMN ${col} ${def}`);
      console.log(`[db] columna ${col} añadida a competitor_scripts`);
    }
  }

  // Columnas de salud del pipeline de competencia en el heartbeat: sin esto,
  // el heartbeat solo veía noticias/clasificación/guiones, y un fallo total
  // del descubrimiento/transcripción de competencia (Apify caído, yt-dlp
  // roto...) seguía marcando el worker como "sano" en el dashboard.
  // heygen_ok/heygen_checked/... y publish_ok/publish_checked/... YA NO se
  // añaden aquí: HeyGen y Metricool se sacaron del ciclo automático (ver
  // runVideoPipelineForUser en pipeline.ts) y ahora corren solo bajo demanda
  // del botón "Continuar proceso de vídeos", que informa de su resultado
  // directamente en pantalla — el heartbeat del worker ya no es quien reporta
  // esa salud. Una base de datos existente puede conservar esas columnas de
  // antes (no se borran, solo dejan de escribirse) sin que nada las lea.
  const hcols = r.prepare(`PRAGMA table_info(worker_heartbeat)`).all() as { name: string }[];
  for (const [col, def] of [
    ["competitor_ok", "INTEGER NOT NULL DEFAULT 1"],
    ["competitor_checked", "INTEGER NOT NULL DEFAULT 0"],
    ["competitor_inserted", "INTEGER NOT NULL DEFAULT 0"],
    ["transcribed_processed", "INTEGER NOT NULL DEFAULT 0"],
    ["transcribed_errors", "INTEGER NOT NULL DEFAULT 0"],
  ] as const) {
    if (!hcols.some((c) => c.name === col)) {
      r.exec(`ALTER TABLE worker_heartbeat ADD COLUMN ${col} ${def}`);
      console.log(`[db] columna ${col} añadida a worker_heartbeat`);
    }
  }

  // Configuración de HeyGen por usuario: clave, avatar/voz elegidos (guardamos
  // también la etiqueta legible para no tener que volver a llamar a HeyGen solo
  // para pintar el nombre en Ajustes) y su propio tope de gasto diario.
  for (const [col, def] of [
    ["heygen_key", "TEXT NOT NULL DEFAULT ''"],
    ["heygen_avatar_id", "TEXT NOT NULL DEFAULT ''"],
    ["heygen_avatar_label", "TEXT NOT NULL DEFAULT ''"],
    ["heygen_voice_id", "TEXT NOT NULL DEFAULT ''"],
    ["heygen_voice_label", "TEXT NOT NULL DEFAULT ''"],
    ["heygen_daily_usd_cap", "REAL NOT NULL DEFAULT 10"],
    // Ventana horaria (UTC) dentro de la cual se auto-programan los vídeos ya
    // generados — fuera de este rango, el siguiente hueco salta al inicio de
    // la ventana en vez de caer, p.ej., a las 3 de la madrugada.
    ["posting_window_start_hour", "INTEGER NOT NULL DEFAULT 8"],
    ["posting_window_end_hour", "INTEGER NOT NULL DEFAULT 22"],
  ] as const) {
    if (!cols.some((c) => c.name === col)) {
      r.exec(`ALTER TABLE user_settings ADD COLUMN ${col} ${def}`);
      console.log(`[db] columna ${col} añadida a user_settings`);
    }
  }

  // Hora del hueco auto-programado (HH:mm, UTC) — separada de scheduled_date
  // a propósito: el calendario manual sigue siendo por DÍA (nada cambia para
  // las publicaciones creadas a mano desde el "+"), y solo los vídeos que
  // salen solos del pipeline de HeyGen llevan una hora concreta, calculada
  // por autoSchedule.ts para espaciarlos entre sí.
  const ccols = r.prepare(`PRAGMA table_info(content_items)`).all() as { name: string }[];
  if (!ccols.some((c) => c.name === "scheduled_time")) {
    r.exec(`ALTER TABLE content_items ADD COLUMN scheduled_time TEXT`);
    console.log("[db] columna scheduled_time añadida a content_items");
  }

  // Metricool: token fijo de tu cuenta (uno solo, como el resto de claves) +
  // el userId de esa cuenta (lo exige la API en cada llamada junto al token).
  for (const [col, def] of [
    ["metricool_user_token", "TEXT NOT NULL DEFAULT ''"],
    ["metricool_user_id", "TEXT NOT NULL DEFAULT ''"],
  ] as const) {
    if (!cols.some((c) => c.name === col)) {
      r.exec(`ALTER TABLE user_settings ADD COLUMN ${col} ${def}`);
      console.log(`[db] columna ${col} añadida a user_settings`);
    }
  }

  r.exec(`
-- ===== METRICOOL: publicar el mismo vídeo en varias cuentas destino =====
-- Una fila por cuenta de cliente conectada en tu panel de Metricool (un
-- blogId). "Misma marca, varias cuentas destino" (confirmado con el
-- usuario) — no hay concepto de "cliente" aquí, solo dónde se publica.
CREATE TABLE IF NOT EXISTS publish_accounts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blog_id     TEXT NOT NULL,
  label       TEXT NOT NULL,
  network     TEXT NOT NULL, -- 'instagram' | 'tiktok' | 'youtube'
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL,
  UNIQUE(user_id, blog_id, network)
);
CREATE INDEX IF NOT EXISTS idx_publish_accounts_user ON publish_accounts(user_id);

-- Una fila por content_item: a QUÉ cuenta se asignó (por rotación, ver
-- publish.ts) y el resultado de ese intento. UNIQUE(content_item_id) a
-- propósito, no (content_item_id, publish_account_id): cada vídeo va a UNA
-- sola cuenta, nunca a varias a la vez (el mismo vídeo en varias cuentas
-- dispara detección de duplicado/spam en Instagram y puede shadowbanear).
CREATE TABLE IF NOT EXISTS content_item_publications (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  content_item_id     INTEGER NOT NULL UNIQUE REFERENCES content_items(id) ON DELETE CASCADE,
  publish_account_id  INTEGER NOT NULL REFERENCES publish_accounts(id) ON DELETE CASCADE,
  metricool_post_id   TEXT,
  status              TEXT NOT NULL DEFAULT 'pending', -- pending|scheduled|error
  error_msg           TEXT,
  created_at          TEXT NOT NULL,
  updated_at          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cip_content_item ON content_item_publications(content_item_id);
`);

  // Cuántas veces se ha intentado la pasada de subtítulos (Whisper + Remotion)
  // de este render. Se incrementa y GUARDA antes de arrancar Remotion, no
  // después: un render que agota la memoria del servidor (Chromium) hace que
  // Render mate el proceso entero, sin que ningún catch llegue a ejecutarse —
  // sin este contador persistido de antemano, ese mismo render se reintentaba
  // en cuanto el proceso volvía a arrancar, una y otra vez, en un bucle de
  // caídas por falta de memoria (visto en producción: dos "Instance failed:
  // ran out of memory" en 7 minutos).
  const hcols2 = r.prepare(`PRAGMA table_info(heygen_renders)`).all() as { name: string }[];
  if (!hcols2.some((c) => c.name === "caption_attempts")) {
    r.exec(`ALTER TABLE heygen_renders ADD COLUMN caption_attempts INTEGER NOT NULL DEFAULT 0`);
    console.log("[db] columna caption_attempts añadida a heygen_renders");
  }
}


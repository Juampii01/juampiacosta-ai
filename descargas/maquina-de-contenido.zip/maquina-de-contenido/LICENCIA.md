# Licencia de uso · Máquina de Contenido

© 2026 Juan Pablo Acosta (Nova Softwares / Forja IA). La Máquina de Contenido es un regalo para quienes se registran en Forja IA.

**Puedes:** instalarla y usarla para tu contenido o el de tus clientes, y modificar las skills para tu uso.

**No puedes:** revenderla, regalarla ni publicarla, completa o en partes, como propia.

**Componentes de terceros:** algunas skills se basan en software con licencia MIT de Jake Schincariol (ver `CREDITOS.md` y la carpeta `licencias/`). Esas partes siguen bajo su licencia MIT original. La fuente Montserrat de los subtítulos tiene licencia SIL OFL 1.1.

Se entrega "tal cual", sin garantías de alcance ni de ventas.

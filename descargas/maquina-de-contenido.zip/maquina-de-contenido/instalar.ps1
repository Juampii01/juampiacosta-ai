# Instala la Máquina de Contenido en Claude Code (Windows). Uso: clic derecho > Ejecutar con PowerShell
# o en PowerShell: powershell -ExecutionPolicy Bypass -File instalar.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$c = Join-Path $env:USERPROFILE ".claude"
New-Item -ItemType Directory -Force (Join-Path $c "skills"), (Join-Path $c "novacut"), (Join-Path $c "maquina") | Out-Null
Copy-Item -Recurse -Force (Join-Path $PSScriptRoot "skills\*") (Join-Path $c "skills")
Copy-Item -Force (Join-Path $PSScriptRoot "templates\voz.md") (Join-Path $c "novacut\plantilla-voz.md")
$env_ = Join-Path $c "maquina\.env"
if (-not (Test-Path $env_)) { "# Pega tu clave de Apify despues del igual (ver setup\guia-apify.md)`nAPIFY_TOKEN=" | Set-Content -Encoding utf8 $env_ }
Write-Host ""
Write-Host "Listo: la Maquina de Contenido quedo instalada en $c\skills"
Write-Host "Ahora:"
Write-Host "  1. Pega tu clave de Apify en $env_ (guia: setup\guia-apify.md)"
Write-Host "  2. Corre: py setup\chequeo.py"
Write-Host "  3. Abre Claude Code en una carpeta para tu contenido y escribe /maquina"

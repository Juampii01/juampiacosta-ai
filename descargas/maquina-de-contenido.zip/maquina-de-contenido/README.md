# Máquina de Contenido

**Tú te grabas. Claude hace el resto.** Un pack de skills para Claude Code que busca qué está funcionando en tu nicho, te escribe los guiones en tu forma de hablar, te edita el video y te arma la descripción.

Es el flujo con el que [@juampiiacosta.ia](https://www.instagram.com/juampiiacosta.ia) hizo más de 70.000 vistas en 14 días, armado para que lo uses en tu propio nicho.

## Cómo funciona

| Paso | Skill | Qué hace |
|---|---|---|
| 0 | `/maquina-perfil` | 8 preguntas: tu nicho, tus cuentas de referencia, qué vendes y cómo hablas |
| 1 | `/maquina-radar` | Trae los reels de tu nicho y los ordena por cuánto superaron a su propia cuenta |
| 2 | `/maquina-guiones` | Saca la estructura de los ganadores y te escribe guiones nuevos en tu voz |
| — | **Tú** | Te grabas |
| 3 | `/nc-editar` | Corta silencios, muletillas y tomas repetidas, iguala el audio y pone subtítulos |
| 4 | `/nc-caption` | Descripción, comentario fijado y texto de portada con tu palabra clave |
| 5 | `/maquina-tablero` | Anota cómo le fue a cada reel y le dice al radar qué repetir |

`/maquina` corre todo en orden y retoma donde quedaste.

## Instalar (3 pasos)

Necesitas **Claude Code** (plan Pro de Claude o superior, o la app de escritorio), una **cuenta gratis de Apify** y, para editar video, **ffmpeg**. La guía completa está en [INSTALAR.md](INSTALAR.md).

1. Descomprime el pack y corre el instalador: `bash instalar.sh` (Mac) o `instalar.ps1` (Windows).
2. Pega tu clave de Apify en `~/.claude/maquina/.env` ([guía de 2 minutos](setup/guia-apify.md)) y corre `python3 setup/chequeo.py`.
3. Abre Claude Code en una carpeta para tu contenido y escribe **`/maquina`**.

## Lo que no hace

- **No publica nada en tus redes** ni se loguea en Instagram. El último clic es tuyo.
- **No copia textos ajenos**: toma la estructura de lo que funciona y escribe con tus palabras.
- **No inventa números**: si un guion necesita un dato tuyo, queda `{{tu número}}`.

## ¿Quieres más?

El **pack completo de NovaCut** (más de 50 skills: carruseles, historias, YouTube, LinkedIn, X, humanizador, plan semanal) y las 138 guías de Forja IA están en el acceso completo de [forjaia.com](https://www.forjaia.com).

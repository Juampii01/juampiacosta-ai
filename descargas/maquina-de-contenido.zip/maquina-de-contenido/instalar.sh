#!/usr/bin/env bash
# Instala la Máquina de Contenido en Claude Code (Mac y Linux). Uso: bash instalar.sh
set -e
cd "$(dirname "$0")"
mkdir -p ~/.claude/skills ~/.claude/novacut ~/.claude/maquina
cp -R skills/* ~/.claude/skills/
cp templates/voz.md ~/.claude/novacut/plantilla-voz.md
if [ ! -f ~/.claude/maquina/.env ]; then
  printf '# Pega tu clave de Apify despues del igual (ver setup/guia-apify.md)\nAPIFY_TOKEN=\n' > ~/.claude/maquina/.env
fi
echo ""
echo "Listo: la Maquina de Contenido quedo instalada en ~/.claude/skills"
echo "Ahora:"
echo "  1. Pega tu clave de Apify en ~/.claude/maquina/.env (guia: setup/guia-apify.md)"
echo "  2. Corre: python3 setup/chequeo.py"
echo "  3. Abre Claude Code en una carpeta para tu contenido y escribe /maquina"

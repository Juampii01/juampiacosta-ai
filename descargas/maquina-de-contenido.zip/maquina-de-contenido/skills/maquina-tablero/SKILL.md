---
name: maquina-tablero
description: >-
  Paso 5 de la Máquina de Contenido. Registra cada reel publicado con sus
  métricas (vistas, comentarios con la palabra clave, seguidores ganados) y le
  dice al radar y a los guiones qué temas y estructuras repetir. Úsala cuando
  el usuario dice "/maquina-tablero", "anota cómo le fue al reel", "cómo vienen
  mis reels", "qué repito", o pega métricas o capturas de sus publicaciones.
---

# maquina-tablero

Cierra el circuito: lo que funcionó vuelve al radar y a los guiones.

## Dónde vive

`./maquina/tablero.md`. Si no existe, créalo con esta tabla:

```markdown
# Tablero

| Fecha | Guion | Estructura | Gancho | Vistas 48 h | Vistas 7 d | Comentarios | Con palabra clave | Seguidores | Link |
|---|---|---|---|---|---|---|---|---|---|
```

## Anotar un reel

El usuario te pasa el link, los números o una captura de las estadísticas de
Instagram. Lee la captura si la manda. Completa la fila:

- **Guion y estructura**: búscalos en `./maquina/guiones/` por tema o por el
  gancho. Si no sale de la Máquina, pon "(propio)".
- **Comentarios con palabra clave**: es la métrica que más importa si vende
  por DM. Si no la sabe, pregúntale cuántos DMs automáticos salieron.
- **Nunca inventes un número.** Lo que no tenga queda vacío y se completa
  después (por ejemplo, las vistas a 7 días).

## Leer el tablero

Con 5 o más filas, responde tres cosas:

1. **Qué repetir**: las 2 estructuras o temas con mejores vistas a 7 días y
   más comentarios con la palabra clave. Escríbelo al final del archivo en una
   sección `## Repetir` (así lo leen `/maquina-radar` y `/maquina-guiones`).
2. **Qué dejar**: lo que quedó debajo de su mediana dos veces seguidas.
3. **El dato honesto**: con menos de 10 reels todo es tendencia, no regla.

La comparación es contra **su propia mediana**, no contra otras cuentas.

## Siguiente

Ofrece una nueva vuelta: `/maquina-radar` (si pasó una semana) o
`/maquina-guiones` con los temas de `## Repetir`.

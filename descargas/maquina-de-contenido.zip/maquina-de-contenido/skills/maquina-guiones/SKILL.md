---
name: maquina-guiones
description: >-
  Paso 2 de la Máquina de Contenido. Toma los reels ganadores del radar, saca
  su estructura (gancho, beats, CTA) y escribe guiones nuevos en la voz del
  usuario, sobre su tema y con su palabra clave. Copia la estructura, nunca el
  texto. Úsala cuando el usuario dice "/maquina-guiones", "escríbeme los
  guiones", "convierte el radar en guiones", "qué grabo esta semana", o cuando
  /maquina llega al paso de guiones.
---

# maquina-guiones

Convierte lo que funciona en el nicho en guiones que el usuario puede grabar
mañana.

## Lo que lees primero

1. `./maquina/radar/reels.json` (lo deja `/maquina-radar`). Si no existe,
   ofrece correr el radar primero.
2. `~/.claude/novacut/nicho.md` y `~/.claude/novacut/voz.md`. Si falta
   alguno, corre `/maquina-perfil` antes. Sin voz, los guiones salen genéricos.
3. `./maquina/tablero.md` si existe: los temas que ya le funcionaron pesan más.

Si los mejores reels no tienen `transcripcion`, ofrece
`radar.py --transcribir 5` (cuesta centavos). Con solo el caption se puede,
pero el guion sale peor y se lo dices.

## Paso 1: desarmar los ganadores

Toma los 5 a 8 reels con mayor múltiplo. Para cada uno escribe su
**esqueleto**, sin copiar frases:

| Parte | Qué anotar |
|---|---|
| Gancho | La fórmula (número de `nc-reel/hooks.json` si la reconoces) y por qué frena el scroll |
| Promesa | Qué le promete al que mira en los primeros 5 segundos |
| Beats | Cuántos y de qué tipo (lista, historia, antes/después, error, paso a paso) |
| Prueba | Qué usa como prueba (número, captura, cliente, demo) |
| CTA | Qué pide y cómo (palabra clave, link, seguir) |
| Duración | Segundos |

Guárdalo en `./maquina/guiones/estructuras.md`.

## Paso 2: escribir los guiones

Pregunta cuántos quiere (por defecto 5). Para cada uno:

- **Una estructura ganadora + un tema del usuario.** El tema sale de su nicho,
  sus pruebas y lo que vende, no del reel ajeno.
- **3 ganchos posibles**, puntuados:
  `python3 ~/.claude/skills/nc-reel/hookscore.py ganchos.txt`. Quédate con el
  mejor y deja los otros dos como alternativa.
- **El guion hablado**, frase por frase, en su voz (`voz.md`: vos/tú, sus
  palabras reales, nada de "potenciar" ni "sumergirse").
- **Texto en pantalla** del primer segundo.
- **CTA con su palabra clave** de `nicho.md`.
- **Tiempos**: `python3 ~/.claude/skills/nc-reel/beats.py guion.txt --target 40`.

Formato de cada archivo `./maquina/guiones/NN-tema-corto.md`:

```markdown
# NN · Tema
Estructura: (de qué reel sale, con el link y el múltiplo)
Duración objetivo: 35-45 s

## Gancho
(elegido) · puntaje
Alternativas: ... / ...

## Texto en pantalla
...

## Guion
1. ...
2. ...

## CTA
Comenta PALABRA y te mando ...
```

## Reglas que no se negocian

- **Copias estructura, nunca texto.** Ninguna frase del reel original puede
  aparecer en el guion, ni traducida. Si una idea es demasiado específica de
  otra persona (su historia, su número), no se usa.
- **No inventes pruebas.** Si el guion necesita un dato que el usuario no te
  dio, deja `{{tu número}}` y avísale.
- Atribuye cada estructura al reel del que salió (en el archivo, no en el guion).

## Al terminar

Muestra los ganchos elegidos de los 5 guiones en una lista y pregunta cuál
graba primero. Cuando tenga el video crudo, el paso siguiente es
`/nc-editar` (o `/maquina` para seguir el circuito).

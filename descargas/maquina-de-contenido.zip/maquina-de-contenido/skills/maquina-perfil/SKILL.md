---
name: maquina-perfil
description: >-
  Paso 0 de la Máquina de Contenido. Entrevista corta (6 a 8 preguntas) para
  armar el perfil del creador: nicho, cuentas de referencia, a quién le habla,
  qué vende, palabra clave de los comentarios y cómo habla. Úsala cuando el
  usuario dice "/maquina-perfil", "arranquemos", "configura la máquina", o
  cuando otra skill de la Máquina necesita ~/.claude/novacut/nicho.md y no existe.
---

# maquina-perfil

Arma los dos archivos que leen todas las skills de la Máquina:

- `~/.claude/novacut/nicho.md`: nicho, cuentas de referencia, oferta y CTA.
- `~/.claude/novacut/voz.md`: cómo habla (lo arma `/nc-voz`).

## Paso 1: ¿ya existe?

Si `nicho.md` existe, léelo, muéstrale un resumen de 3 líneas y pregunta qué
quiere cambiar. No lo pises entero.

## Paso 2: las preguntas, en un solo bloque

Máximo 8. Pregúntalas juntas, numeradas, para que responda de una:

1. ¿De qué es tu contenido y a quién le hablas? (rubro, país, nivel)
2. ¿Qué vendes o a dónde quieres llevar a la gente? (DM, link, llamada, nada todavía)
3. ¿Qué palabra clave usas para los comentarios? (ej. GUÍA, PLAN). Si no tienes, la armamos.
4. Pásame entre 4 y 10 cuentas de Instagram de tu nicho que te gusten o que te
   gustaría alcanzar. Si no conoces ninguna, te propongo yo.
5. ¿Hablas con vos, con tú o con vosotros?
6. ¿Muestras la cara? ¿Grabas solo a cámara o también pantalla?
7. ¿Qué resultado real tuyo o de un cliente puedo usar como prueba? (si no hay, se deja en blanco)
8. ¿Hay algo que nunca dirías o temas que no tocas?

Si no conoce cuentas, propón de 6 a 8 que conozcas del nicho (directas y
vecinas) y que elija. **No inventes cuentas**: si no estás seguro de que
existe, no la propongas.

## Paso 3: escribir nicho.md

```markdown
# Nicho
- Tema: ...
- A quién le hablo: ...
- Qué vendo / a dónde llevo: ...
- Palabra clave: ...
- Formato: cara a cámara / pantalla / ambos

# Cuentas de referencia
- @cuenta1 (directa)
- @cuenta2 (vecina)
...

# Pruebas reales
- ... (o {{tu número}} si no hay)

# No se toca
- ...
```

Muéstralo y pregunta: **¿lo guardo así?** Con un sí, guárdalo en
`~/.claude/novacut/nicho.md` (crea la carpeta si no existe).

## Paso 4: la voz

Si `~/.claude/novacut/voz.md` no existe, sigue con `/nc-voz`. Ya tienes las
respuestas 2, 3, 5 y 7: no las vuelvas a preguntar, pásalas y pide solo el
material real (3 reels o textos suyos).

## Paso 5: siguiente

Ofrece `/maquina-radar` con las cuentas que acaba de confirmar.

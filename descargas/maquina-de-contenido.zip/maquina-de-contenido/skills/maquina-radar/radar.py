#!/usr/bin/env python3
"""
radar.py - trae los últimos reels de las cuentas de tu nicho con Apify, calcula
cuánto superó cada reel a su propia cuenta (vistas / mediana de la cuenta) y
deja los mejores listos para escribir guiones.

Solo usa datos públicos, con el actor público apify/instagram-reel-scraper.
No se loguea en Instagram ni usa tu cuenta.

Uso
  python3 radar.py --cuentas cuenta1,cuenta2,cuenta3 --por-cuenta 12 --estimar
  python3 radar.py --cuentas cuenta1,cuenta2,cuenta3 --por-cuenta 12
  python3 radar.py --transcribir 5            # transcribe los 5 mejores (add-on de Apify)
  python3 radar.py --demo                     # prueba sin gastar: usa demo.json (cuentas inventadas)

La clave de Apify se lee de APIFY_TOKEN o de ~/.claude/maquina/.env (APIFY_TOKEN=...).
Todo se guarda en ./maquina/radar/ (desde la carpeta donde corres Claude Code).
"""

import argparse
import csv
import json
import os
import statistics
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

ACTOR = "apify~instagram-reel-scraper"
# Precios del plan gratis de Apify (noviembre 2026). Se usan solo para avisar antes de gastar.
PRECIO_REEL = 0.0026
PRECIO_INICIO = 0.001
PRECIO_MINUTO_TRANSCRIPCION = 0.048
MAX_REELS = 400  # tope por corrida para que nadie se gaste el crédito sin querer

AQUI = os.path.dirname(os.path.abspath(__file__))
SALIDA = os.path.join(os.getcwd(), "maquina", "radar")


def token():
    t = os.environ.get("APIFY_TOKEN", "").strip()
    if t:
        return t
    env = os.path.expanduser("~/.claude/maquina/.env")
    if os.path.exists(env):
        for linea in open(env, encoding="utf-8"):
            if linea.strip().startswith("APIFY_TOKEN="):
                v = linea.split("=", 1)[1].strip().strip('"').strip("'")
                if v:
                    return v
    sys.exit("Falta la clave de Apify. Guárdala en ~/.claude/maquina/.env como APIFY_TOKEN=... "
             "(ver setup/guia-apify.md). Nunca la pegues en el chat.")


def correr_actor(entrada, espera=300):
    url = f"https://api.apify.com/v2/acts/{ACTOR}/run-sync-get-dataset-items?" + urllib.parse.urlencode({"timeout": espera})
    req = urllib.request.Request(url, data=json.dumps(entrada).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "Authorization": "Bearer " + token()})
    try:
        with urllib.request.urlopen(req, timeout=espera + 30) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        cuerpo = e.read()[:400].decode(errors="ignore")
        if e.code == 401:
            sys.exit("Apify rechazó la clave (401). Revisa APIFY_TOKEN en ~/.claude/maquina/.env.")
        if e.code == 402:
            sys.exit("Se terminó el crédito de Apify de este mes (402). Espera al mes que viene o carga crédito.")
        if e.code == 408:
            sys.exit("Apify tardó demasiado. Prueba con menos cuentas o menos reels por cuenta.")
        sys.exit(f"Apify devolvió {e.code}: {cuerpo}")
    except urllib.error.URLError as e:
        sys.exit(f"No se pudo conectar con Apify: {e.reason}")


def plata(x):
    return ("%.2f" % x).replace(".", ",")


def limpiar_cuenta(c):
    c = c.strip().rstrip("/")
    if "instagram.com/" in c:
        c = c.split("instagram.com/")[1].split("/")[0]
    return c.lstrip("@").strip()


def numero(x):
    try:
        return int(x or 0)
    except (TypeError, ValueError):
        return 0


def ordenar(items):
    """Agrupa por cuenta, calcula la mediana de vistas de cada una y el múltiplo de cada reel."""
    por_cuenta = {}
    for it in items:
        if it.get("error") or not it.get("url"):
            continue
        cuenta = it.get("ownerUsername") or it.get("username") or "?"
        por_cuenta.setdefault(cuenta, []).append(it)
    filas = []
    for cuenta, reels in por_cuenta.items():
        vistas = [numero(r.get("videoPlayCount") or r.get("videoViewCount")) for r in reels]
        vistas_validas = [v for v in vistas if v > 0]
        mediana = statistics.median(vistas_validas) if vistas_validas else 0
        for r, v in zip(reels, vistas):
            caption = (r.get("caption") or "").strip()
            filas.append({
                "cuenta": "@" + cuenta,
                "seguidores": numero(r.get("followersCount")),
                "mediana": int(mediana),
                "vistas": v,
                "multiplo": round(v / mediana, 1) if mediana else 0,
                "comentarios": numero(r.get("commentsCount")),
                "likes": numero(r.get("likesCount")),
                "duracion": round(float(r.get("videoDuration") or 0)),
                "fecha": (r.get("timestamp") or "")[:10],
                "url": r.get("url"),
                "gancho": caption.split("\n")[0][:160],
                "caption": caption[:1500],
                "transcripcion": r.get("transcript") or r.get("transcription") or "",
            })
    filas.sort(key=lambda f: (f["multiplo"], f["vistas"]), reverse=True)
    return filas


def guardar(filas, cuentas):
    os.makedirs(SALIDA, exist_ok=True)
    with open(os.path.join(SALIDA, "reels.json"), "w", encoding="utf-8") as f:
        json.dump({"fecha": datetime.now(timezone.utc).isoformat()[:16], "cuentas": cuentas, "reels": filas}, f, ensure_ascii=False, indent=1)
    # TSV para swipe/hookscore: cuenta, seguidores, mediana, vistas, gancho
    with open(os.path.join(SALIDA, "capturados.tsv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["cuenta", "seguidores", "mediana", "vistas", "gancho"])
        for r in filas:
            w.writerow([r["cuenta"], r["seguidores"], r["mediana"], r["vistas"], r["gancho"].replace("\t", " ")])
    with open(os.path.join(SALIDA, "reels.csv"), "w", encoding="utf-8-sig", newline="") as f:
        campos = ["cuenta", "vistas", "mediana", "multiplo", "comentarios", "likes", "duracion", "fecha", "url", "gancho"]
        w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
        w.writeheader()
        w.writerows(filas)
    # Resumen legible
    top = [r for r in filas if r["multiplo"] >= 1.5][:15] or filas[:10]
    lineas = [f"# Radar · {len(filas)} reels de {len(set(r['cuenta'] for r in filas))} cuentas",
              "", "Ordenado por cuánto superó cada reel a la mediana de su propia cuenta (no por vistas).", "",
              "| # | Múltiplo | Vistas | Cuenta | Gancho (1.ª línea del caption) | Link |", "|---|---|---|---|---|---|"]
    for i, r in enumerate(top, 1):
        g = r["gancho"].replace("|", "/")[:90]
        mult = str(r["multiplo"]).replace(".", ",")
        vistas = f"{r['vistas']:,}".replace(",", ".")
        lineas.append(f"| {i} | {mult}x | {vistas} | {r['cuenta']} | {g} | {r['url']} |")
    with open(os.path.join(SALIDA, "top-reels.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lineas) + "\n")
    return top


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # consola de Windows
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Radar de reels de tu nicho (Apify)")
    ap.add_argument("--cuentas", help="cuentas separadas por coma (con o sin @, o links)")
    ap.add_argument("--por-cuenta", type=int, default=12, help="reels por cuenta (por defecto 12)")
    ap.add_argument("--desde", default="90 days", help="solo reels más nuevos que esto (por defecto 90 days)")
    ap.add_argument("--estimar", action="store_true", help="solo muestra cuánto cuesta, no gasta nada")
    ap.add_argument("--transcribir", type=int, metavar="N", help="transcribe los N mejores del último radar")
    ap.add_argument("--demo", action="store_true", help="usa datos de ejemplo, sin Apify")
    a = ap.parse_args()

    if a.demo:
        items = json.load(open(os.path.join(AQUI, "demo.json"), encoding="utf-8"))
        top = guardar(ordenar(items), ["(demo)"])
        print(f"Demo listo: {len(top)} reels en {os.path.join(SALIDA, 'top-reels.md')}")
        return

    if a.transcribir:
        path = os.path.join(SALIDA, "reels.json")
        if not os.path.exists(path):
            sys.exit("Primero corre el radar (no hay maquina/radar/reels.json).")
        datos = json.load(open(path, encoding="utf-8"))
        top = [r for r in datos["reels"] if not r.get("transcripcion")][: a.transcribir]
        if not top:
            print("Los mejores ya están transcritos.")
            return
        minutos = sum(max(1, -(-r["duracion"] // 60)) for r in top)
        costo = PRECIO_INICIO + len(top) * PRECIO_REEL + minutos * PRECIO_MINUTO_TRANSCRIPCION
        print(f"Transcribir {len(top)} reels (~{minutos} min de audio) cuesta unos US$ {plata(costo)} del crédito de Apify.")
        res = correr_actor({"username": [r["url"] for r in top], "includeTranscript": True})
        por_url = {}
        for it in res:
            t = it.get("transcript") or it.get("transcription") or ""
            if isinstance(t, list):
                t = " ".join(x.get("text", "") if isinstance(x, dict) else str(x) for x in t)
            for k in ("url", "inputUrl"):
                if it.get(k):
                    por_url[it[k].rstrip("/")] = t
            if it.get("shortCode"):
                por_url[it["shortCode"]] = t
        n = 0
        for r in datos["reels"]:
            u = r["url"].rstrip("/")
            t = por_url.get(u) or por_url.get(u.split("/")[-1])
            if t:
                r["transcripcion"] = t
                n += 1
        json.dump(datos, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"Transcritos: {n} de {len(top)}. Quedaron en maquina/radar/reels.json.")
        return

    if not a.cuentas:
        sys.exit("Pasa las cuentas con --cuentas cuenta1,cuenta2 (o usa --demo).")
    cuentas = [limpiar_cuenta(c) for c in a.cuentas.split(",") if c.strip()]
    if not cuentas:
        sys.exit("No hay cuentas válidas.")
    total = len(cuentas) * a.por_cuenta
    if total > MAX_REELS:
        sys.exit(f"Son {total} reels: el tope por corrida es {MAX_REELS}. Baja --por-cuenta o la cantidad de cuentas.")
    costo = PRECIO_INICIO + total * PRECIO_REEL
    print(f"{len(cuentas)} cuentas x {a.por_cuenta} reels = hasta {total} reels · unos US$ {plata(costo)} del crédito de Apify "
          f"(el plan gratis trae US$ 5 por mes).")
    if a.estimar:
        return
    items = correr_actor({"username": cuentas, "resultsLimit": a.por_cuenta, "onlyPostsNewerThan": a.desde, "skipPinnedPosts": True})
    filas = ordenar(items)
    if not filas:
        sys.exit("Apify no devolvió reels. Revisa que las cuentas existan y sean públicas.")
    top = guardar(filas, cuentas)
    print(f"Listo: {len(filas)} reels. Los {len(top)} mejores en maquina/radar/top-reels.md")
    for i, r in enumerate(top[:5], 1):
        print(f"  {i}. {str(r['multiplo']).replace('.', ',')}x  {r['cuenta']}  {r['gancho'][:70]}")


if __name__ == "__main__":
    main()

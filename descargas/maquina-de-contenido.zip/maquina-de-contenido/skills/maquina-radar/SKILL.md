---
name: maquina-radar
description: >-
  Paso 1 de la Máquina de Contenido. Trae con Apify los últimos reels de las
  cuentas del nicho del usuario y los ordena por cuánto superó cada uno a su
  propia cuenta (no por vistas), para saber qué temas y ganchos están
  funcionando ahora. Úsala cuando el usuario dice "/maquina-radar", "busca qué
  funciona en mi nicho", "trae los reels de mi competencia", "qué está
  funcionando", o cuando /maquina llega al paso del radar.
---

# maquina-radar

Sale a mirar qué funciona en el nicho del usuario. Todo lo demás de la Máquina
se apoya en lo que encuentra esta skill.

## Antes de correr

1. Lee `~/.claude/novacut/nicho.md`. Ahí están las cuentas (las arma
   `/maquina-perfil`). Si no existe, pide entre 4 y 10 cuentas del nicho:
   - directas (mismo nicho, un poco más adelante),
   - vecinas (otro nicho, mismo público),
   - y como mucho 2 grandes, solo por el formato.
   Si el usuario no conoce ninguna, propón cuentas que conozcas del nicho y
   pídele que las confirme. **Nunca corras el radar con cuentas que no aprobó.**
2. Comprueba la clave de Apify sin mostrarla:
   `python3 -c "import os;p=os.path.expanduser('~/.claude/maquina/.env');print('ok' if os.path.exists(p) and 'APIFY_TOKEN=' in open(p).read() else 'falta')"`
   Si falta, guíalo con `setup/guia-apify.md` del pack (2 minutos). **Nunca le
   pidas que pegue la clave en el chat**: la guarda él en ese archivo.

## Correr

Primero el costo, siempre:

```bash
python3 ~/.claude/skills/maquina-radar/radar.py --cuentas cuenta1,cuenta2,cuenta3 --por-cuenta 12 --estimar
```

Dile el número ("unos US$ 0,30 del crédito gratis de Apify, que trae US$ 5 por
mes") y espera su OK. Después:

```bash
python3 ~/.claude/skills/maquina-radar/radar.py --cuentas cuenta1,cuenta2,cuenta3 --por-cuenta 12
```

En Windows usa `py` en vez de `python3` y la ruta
`%USERPROFILE%\.claude\skills\maquina-radar\radar.py`.

Deja en `./maquina/radar/`:

| Archivo | Qué es |
|---|---|
| `top-reels.md` | Los mejores, ordenados por múltiplo sobre su cuenta |
| `reels.json` | Todo, con caption y (si se pidió) transcripción |
| `reels.csv` | Para abrir en Excel o Google Sheets |
| `capturados.tsv` | Formato para puntuar ganchos con `nc-reel/hookscore.py` |

Para escribir guiones hace falta lo que se **dijo** en los reels, no solo el
caption. Transcribe los 5 mejores (avisa el costo antes, el script lo imprime):

```bash
python3 ~/.claude/skills/maquina-radar/radar.py --transcribir 5
```

¿Solo quiere ver cómo funciona sin gastar? `radar.py --demo` (cuentas inventadas).

## Qué decirle después

Tres cosas, cortas:

1. **Los 3 reels que más superaron a su cuenta**, con el múltiplo y el gancho.
   Arriba de 3x es una señal; debajo de 1,5x es un día normal de esa cuenta.
2. **Qué temas o formatos se repiten arriba** (con conteos, no impresiones).
3. **El tamaño de la muestra.** 40 reels de 6 cuentas sostienen una
   conclusión; 12 no, y se dice.

Si existe `./maquina/tablero.md` (lo escribe `/maquina-tablero`), cruza: ¿los
temas que le funcionaron al usuario aparecen arriba en el radar? Dilo.

Después ofrece el paso siguiente: `/maquina-guiones`.

## Reglas

- Solo datos públicos con el actor público `apify/instagram-reel-scraper`.
  Nunca pidas el usuario o la contraseña de Instagram.
- Una corrida por semana alcanza. El script corta en 400 reels por corrida.
- Nada de esto se publica ni se comparte: es investigación del usuario.

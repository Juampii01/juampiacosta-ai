# Instalar la Máquina de Contenido

## Lo que necesitas

| | Para qué | Costo |
|---|---|---|
| **Claude Code** | Corre las skills | Plan Pro de Claude o superior (el plan gratis no incluye Claude Code) |
| **Python 3.10+** | Los scripts del radar y de los guiones | Gratis |
| **Cuenta de Apify** | Traer los reels de tu nicho | Gratis: US$ 5 de crédito por mes |
| **ffmpeg + faster-whisper** | Solo para editar video (paso 3) | Gratis |

## 1. Claude Code

Si ya lo tienes, salta al paso 2.

- Mac (Terminal): `curl -fsSL https://claude.ai/install.sh | bash`
- Windows (PowerShell): `irm https://claude.ai/install.ps1 | iex`

Cierra y abre la terminal, escribe `claude` e inicia sesión. También viene dentro de la app de escritorio de Claude.

## 2. Instalar el pack

Descomprime el ZIP, abre la terminal **dentro de la carpeta** `maquina-de-contenido` y corre:

- Mac: `bash instalar.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File instalar.ps1`

Copia las skills a `~/.claude/skills` y crea el archivo donde va tu clave de Apify.

## 3. Tu clave de Apify

Sigue [setup/guia-apify.md](setup/guia-apify.md) (2 minutos) y después comprueba todo:

- Mac: `python3 setup/chequeo.py`
- Windows: `py setup\chequeo.py`

Con eso ya funcionan el perfil, el radar y los guiones.

## 4. Edición de video (opcional, para el paso 3)

El editor corre en tu computadora y no sube tu video a ningún lado. Necesita ffmpeg, Python y faster-whisper. Los pasos para Mac y Windows están en `skills/nc-editar/instalar_dependencias.md`.

Atajo: abre Claude Code y escribe *"instálame las dependencias del editor"*. Te guía y te pide permiso antes de cada comando.

## 5. Usarla

Crea una carpeta para tu contenido (por ejemplo `Contenido`), abre Claude Code adentro y escribe:

```
/maquina
```

Todo lo que genera queda en `Contenido/maquina/` (radar, guiones, publicaciones y tablero) y tu perfil en `~/.claude/novacut/`.

## Si algo falla

| Problema | Qué hacer |
|---|---|
| `/maquina` no aparece | Cierra y abre Claude Code. Si sigue, corre de nuevo el instalador |
| "Falta la clave de Apify" | Revisa que `~/.claude/maquina/.env` tenga `APIFY_TOKEN=` con la clave pegada después del igual |
| Apify 402 | Se terminó el crédito gratis del mes. Espera al mes siguiente o carga crédito |
| El radar no trae reels | Las cuentas tienen que ser públicas y estar bien escritas |
| El editor dice que falta algo | Corre `python3 ~/.claude/skills/nc-editar/verificar.py` y sigue lo que imprime |

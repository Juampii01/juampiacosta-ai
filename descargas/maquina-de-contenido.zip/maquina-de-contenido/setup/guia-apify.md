# Tu clave de Apify (2 minutos)

La Máquina usa Apify para traer los reels públicos de las cuentas de tu nicho. El plan gratis de Apify trae **US$ 5 de crédito por mes**: alcanza para unos 1.500 reels o, por ejemplo, 4 radares semanales de 8 cuentas.

1. Entra en [apify.com](https://apify.com) y crea una cuenta gratis (con Google es un clic). No pide tarjeta.
2. Arriba a la izquierda, tu nombre → **Settings** → **API & Integrations**.
3. En **Personal API tokens**, copia el token (botón de copiar).
4. Abre el archivo `.env` de la Máquina y pega el token después del igual:
   - Mac: `~/.claude/maquina/.env` (en la Terminal: `open -e ~/.claude/maquina/.env`)
   - Windows: `%USERPROFILE%\.claude\maquina\.env` (en PowerShell: `notepad $env:USERPROFILE\.claude\maquina\.env`)

   Tiene que quedar así, en una sola línea:
   ```
   APIFY_TOKEN=apify_api_xxxxxxxxxxxxxxxxxxxx
   ```
5. Guarda y corre `python3 setup/chequeo.py` (Windows: `py setup\chequeo.py`). Tiene que decir ✓ Clave de Apify.

**Nunca pegues la clave en el chat con Claude** ni la subas a GitHub. Si se te filtró, en la misma pantalla de Apify puedes crear una nueva y borrar la vieja.

**Cuánto gasta cada cosa** (precios del plan gratis, noviembre 2026):
- Cada reel que trae el radar: US$ 0,0026 (100 reels ≈ US$ 0,26).
- Transcribir un reel: US$ 0,048 por minuto de audio (los 5 mejores ≈ US$ 0,25).

El radar siempre te muestra el costo antes de gastar.

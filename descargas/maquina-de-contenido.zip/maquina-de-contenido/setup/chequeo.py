#!/usr/bin/env python3
"""Revisa que esté todo para usar la Máquina de Contenido. Uso: python3 setup/chequeo.py (Windows: py setup\\chequeo.py)"""
import os, shutil, subprocess, sys, json, urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8")  # consola de Windows
except Exception:
    pass

ok = True
def linea(estado, texto, ayuda=""):
    global ok
    print(("  ✓ " if estado else "  ✗ ") + texto + ("" if estado or not ayuda else "\n      → " + ayuda))
    if not estado: ok = False

print("\nMáquina de Contenido · chequeo\n")
home = os.path.expanduser("~/.claude")
skills = ["maquina", "maquina-perfil", "maquina-radar", "maquina-guiones", "maquina-tablero", "nc-voz", "nc-reel", "nc-caption", "nc-editar", "nc-cortar", "nc-audio", "nc-subtitulos"]
faltan = [s for s in skills if not os.path.exists(os.path.join(home, "skills", s, "SKILL.md"))]
linea(not faltan, "Skills instaladas" + (f" (faltan: {', '.join(faltan)})" if faltan else ""), "Corre instalar.sh (Mac) o instalar.ps1 (Windows).")
linea(sys.version_info >= (3, 8), f"Python {sys.version.split()[0]}", "Instala Python 3.10 o más nuevo.")
linea(bool(shutil.which("claude")), "Claude Code", "Instálalo: https://claude.ai/code (o usa la app de escritorio de Claude).")

# Apify
token = os.environ.get("APIFY_TOKEN", "")
env = os.path.join(home, "maquina", ".env")
if not token and os.path.exists(env):
    for l in open(env, encoding="utf-8"):
        if l.strip().startswith("APIFY_TOKEN="):
            token = l.split("=", 1)[1].strip().strip('"').strip("'")
if not token:
    linea(False, "Clave de Apify", f"Pégala en {env} (guía: setup/guia-apify.md). No la pegues en el chat.")
else:
    try:
        req = urllib.request.Request("https://api.apify.com/v2/users/me", headers={"Authorization": "Bearer " + token})
        d = json.loads(urllib.request.urlopen(req, timeout=20).read())["data"]
        linea(True, f"Clave de Apify (cuenta {d.get('username', '?')})")
    except Exception as e:
        linea(False, "Clave de Apify", f"Apify la rechazó ({e}). Cópiala de nuevo desde Apify → Settings → API & Integrations.")

# Edición (opcional para los pasos 0 a 2)
print("\nPara editar video (paso 3):")
ff = shutil.which("ffmpeg")
linea(bool(ff), "ffmpeg", "Mac: brew install ffmpeg · Windows: winget install Gyan.FFmpeg (ver skills/nc-editar/instalar_dependencias.md)")
try:
    import faster_whisper  # noqa: F401
    fw = True
except Exception:
    venv = os.path.join(home, "novacut", "venv")
    fw = os.path.exists(venv)
linea(fw, "faster-whisper (transcripción local)", "Sigue skills/nc-editar/instalar_dependencias.md o dile a Claude Code: instálame las dependencias del editor")

print("\n" + ("Todo listo. Abre Claude Code en una carpeta para tu contenido y escribe /maquina\n" if ok else
      "Arregla lo marcado con ✗. El radar y los guiones funcionan sin la parte de video.\n"))

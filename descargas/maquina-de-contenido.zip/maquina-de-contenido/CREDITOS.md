# Créditos

La Máquina de Contenido es de Juampi Acosta (Nova Softwares / Forja IA) y usa parte de NovaCut Skills.

- `nc-reel` y `nc-caption` están basadas en [instagram-agent-skill](https://github.com/Jakeschincariol/instagram-agent-skill) de Jake Schincariol, con licencia MIT ([texto](licencias/LICENSE-instagram-agent-skill.txt)), adaptadas al español.
- La fuente **Montserrat** (`skills/nc-subtitulos/fuentes/`) es de Julieta Ulanovsky y colaboradores, con licencia SIL Open Font License 1.1.
- `maquina`, `maquina-perfil`, `maquina-radar`, `maquina-guiones`, `maquina-tablero`, `nc-voz`, `nc-editar`, `nc-cortar`, `nc-audio` y `nc-subtitulos` son de NovaCut / Forja IA.
- El radar usa el actor público [apify/instagram-reel-scraper](https://apify.com/apify/instagram-reel-scraper) con la cuenta de Apify de cada usuario.

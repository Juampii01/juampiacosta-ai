# Nicho (ejemplo)
- Tema: entrenamiento y nutrición para gente ocupada que quiere bajar grasa sin dietas extremas
- A quién le hablo: mujeres y hombres de 28 a 45 años, Latinoamérica, trabajan full time
- Qué vendo / a dónde llevo: plan de entrenamiento online de 12 semanas; por DM
- Palabra clave: PLAN
- Formato: cara a cámara, a veces en el gimnasio

# Cuentas de referencia
- @coach.vale_demo (directa)
- @entrena.con.tomi_demo (directa)
- @nutri.sofi_demo (vecina)

# Pruebas reales
- {{tu número}} alumnos que terminaron el plan
- {{tu número}} kilos promedio en 12 semanas

# No se toca
- Medicamentos para bajar de peso
- Fotos de antes y después de alumnos sin permiso

#!/bin/zsh
# Instala lo que hace falta para Carrusel Creator Pro en un Mac. Se puede ejecutar varias veces.
# En Windows se usa windows/instalar.ps1. Los pasos, explicados, en mac/install.md.
set -e
AQUI="${0:A:h:h}"  # carpeta del proyecto (este script está en mac/)
echo "Carrusel Creator Pro · instalación (Mac)"
[ "$(uname)" = "Darwin" ] || { echo "Este instalador es para Mac. En Windows usa windows/instalar.ps1."; exit 1; }

if ! command -v brew >/dev/null; then
  echo "Falta Homebrew. Instálalo desde https://brew.sh y vuelve a ejecutar este script."; exit 1
fi
BREW="$(brew --prefix)"
export PATH="$BREW/bin:$PATH"  # el motor usa las herramientas de Homebrew primero: aquí también
for f in node ffmpeg exiftool; do
  if command -v $f >/dev/null; then echo "  ✓ $f"; else echo "  → instalando $f"; brew install $f; fi
done
NODE_MAJOR=$(node --version 2>/dev/null | sed 's/v\([0-9]*\).*/\1/'); [ "${NODE_MAJOR:-0}" -ge 20 ] || { echo "  ! Node $(node --version) es antiguo: la app necesita Node 20 o más (brew upgrade node)"; exit 1; }
# python3 de Homebrew (no el del sistema): con él corren ficha.py, bajar.py y el vídeo de los slides (motor/animar.py, con numpy)
if [ -x "$BREW/bin/python3" ]; then echo "  ✓ python3 ($("$BREW/bin/python3" --version 2>&1 | awk '{print $2}'))"; else echo "  → instalando python"; brew install python; fi
if "$BREW/bin/python3" -c "import numpy" 2>/dev/null; then echo "  ✓ numpy"; else echo "  → instalando numpy"; brew install numpy; fi
"$BREW/bin/python3" -c "import numpy" 2>/dev/null || { echo "  ! El python3 de Homebrew no encuentra numpy. Ejecuta  brew reinstall numpy  y vuelve a ejecutar este script."; exit 1; }
# Versiones probadas con el motor (opciones como --ephemeral o --tools ""): una versión distinta puede romperlo.
CODEX_PROBADO="0.158.0"; CLAUDE_MIN="2.1"
if command -v codex >/dev/null; then
  v=$(codex --version 2>/dev/null | awk '{print $2}'); [ "$v" = "$CODEX_PROBADO" ] && echo "  ✓ codex $v" || echo "  ! codex $v: el motor está probado con $CODEX_PROBADO. Si falla al generar: npm install -g @openai/codex@$CODEX_PROBADO"
else echo "  → instalando Codex CLI $CODEX_PROBADO"; npm install -g @openai/codex@$CODEX_PROBADO; fi
if command -v claude >/dev/null || [ -x "$HOME/.local/bin/claude" ]; then echo "  ✓ claude $(claude --version 2>/dev/null | awk '{print $1}') (mínimo $CLAUDE_MIN)"; else echo "  → instalando Claude Code"; npm install -g @anthropic-ai/claude-code; fi

echo "  → dependencias de la app"
(cd "$AQUI/app" && npm install --silent)
# datos/: el primer cliente (perfiles/mi_marca), igual que lo crea la app. No toca datos que ya existan.
"$BREW/bin/python3" "$AQUI/motor/preparar_datos.py" "$AQUI/datos" | sed 's/^/  ✓ /'
chmod +x "$AQUI"/mac/*.sh "$AQUI"/mac/motor/*.sh "$AQUI"/mac/motor/pruebas/*.sh "$AQUI"/motor/*.py 2>/dev/null || true

echo
if codex login status 2>&1 | grep -qi "logged in" && ! codex login status 2>&1 | grep -qi "not logged in"; then echo "  ✓ Codex conectado"; else echo "  ! Codex sin sesión: ejecuta  codex login  (se abre el navegador)"; fi
echo
echo "Listo. Arranca con:  mac/arrancar.sh   (se abre sola en http://carrusel.localhost:3000)"
echo "Primera vez: la app abre la bienvenida (tu marca, tus fotos, la clave de ScrapeCreators y las conexiones)."
echo "Opcional: instala la app desde Chrome y ejecuta  mac/crear-lanzador.sh  para abrirla desde el Dock sin Terminal (enciende y apaga el servidor solo)."

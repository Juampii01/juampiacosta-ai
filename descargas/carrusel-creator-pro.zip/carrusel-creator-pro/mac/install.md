# Instalar Carrusel Creator Pro en Mac

Guía paso a paso. Sirve para una persona y para Claude Code: si le dices a Claude *"instálame esta app"*, sigue estos mismos pasos y te avisa de lo que tienes que hacer tú.

> ¿Tienes Windows? La guía es otra: [`windows/install.md`](../windows/install.md).

## Qué necesitas

| Qué | Para qué |
|---|---|
| Un Mac con [Homebrew](https://brew.sh) | Instala las herramientas (Node, ffmpeg, exiftool, Python y numpy) |
| Una cuenta de ChatGPT | Codex genera las imágenes con tu plan (unas 60 al día por cuenta) |
| Una cuenta de Claude | Claude Code redacta las fichas y las descripciones |
| Una clave de [ScrapeCreators](https://scrapecreators.com) | Descarga los carruseles originales (1 crédito por carrusel). Sin clave puedes trabajar con tu propio guion |
| De 1 a 3 fotos tuyas y de 1 a 3 referencias de estilo | Para que salgas tú en los slides, con tu estilo |

## Pasos

### 1. Homebrew

En la Terminal, comprueba que está: `brew --version`. Si no está, instálalo desde https://brew.sh (te pide la contraseña del Mac: eso lo haces tú).

### 2. Instalador

Dentro de la carpeta de la app:

```bash
mac/instalar.sh
```

Instala lo que falte y deja todo listo:

- Node (20 o más), ffmpeg y exiftool, con Homebrew.
- Python 3 y **numpy** de Homebrew (numpy hace los vídeos de los slides).
- Codex CLI en la versión probada (**0.158.0**) y Claude Code, si no los tienes.
- Las dependencias de la app.
- La carpeta `datos/` con tu primer cliente (`datos/perfiles/mi_marca`). Si ya tenías datos, no los toca.

Se puede ejecutar todas las veces que quieras. Lee lo que dice al final: si algo falta, lo pone con `!`.

### 3. Conectar Codex

Si el instalador dice *"Codex sin sesión"*, ejecuta `codex login`: se abre el navegador con tu cuenta de ChatGPT. Ese paso lo haces tú (Claude no escribe contraseñas).

### 4. Arrancar

```bash
mac/arrancar.sh
```

Se abre sola en **http://carrusel.localhost:3000** (usa siempre esa dirección, con Chrome). Deja abierta la ventana de la Terminal mientras usas la app: al cerrarla se apaga.

### 5. Bienvenida

La primera vez sale la **bienvenida** (unos 3 minutos): tu nombre, tu cuenta de Instagram, el color, a quién le hablas, tus fotos, tus referencias de estilo, la ropa, la clave de ScrapeCreators, la comprobación de Codex y Claude, y la ubicación de los metadatos. Las claves se pegan en la app, nunca en el chat.

### 6. Que Claude te conozca

Abre Claude Code en la carpeta (`claude`). La primera vez te pregunta tu nombre y crea **`datos/usuario.md`**, donde apunta tu nombre, tus gustos y los cambios que le pidas. Así te recuerda en cada conversación. Ese archivo es tuyo: está en `datos/` y nunca se sube a GitHub.

### 7. Opcional: abrirla desde el Dock, sin Terminal

Con un icono en el Dock, al abrirlo se enciende el servidor y al cerrar la app (X o Cmd+Q) se apaga solo.

1. Con `mac/arrancar.sh` en marcha, instala la app desde Chrome: icono de **Instalar** en la barra de direcciones (o menú ⋮ → *Transmitir, guardar y compartir* → *Instalar página como aplicación*). Ese clic lo haces tú.
2. Ejecuta `mac/crear-lanzador.sh`. Crea `~/Applications/Carrusel Creator Pro.app` con el logo de Forja IA.
3. Para el `mac/arrancar.sh` del paso 4: desde ahora lo enciende el icono.
4. Arrastra el icono nuevo al Dock y quita el que puso Chrome (clic derecho → Opciones → Quitar del Dock). Ábrela siempre desde el icono nuevo.
5. Comprobación: al abrir el icono, la app carga; al cerrarla, `curl -s -o /dev/null -w '%{http_code}' http://localhost:3000/` da `000`. Si algo falla, el registro está en `~/Library/Logs/carrusel-creator-pro.log`.

Si mueves la carpeta de la app, vuelve a ejecutar `mac/crear-lanzador.sh`. Para quitarlo: `mac/crear-lanzador.sh --quitar`.

## Comprobar que todo va

- En la app, **Ajustes → Herramientas de tu equipo**: codex, claude, ffmpeg, exiftool, python y numpy en verde.
- Pruebas del motor, sin gastar imágenes ni créditos: `mac/motor/pruebas/correr.sh` tiene que terminar con *"fallan 0"*.

## Actualizar

```bash
git pull
mac/instalar.sh
```

Tus datos (`datos/`) no se tocan. Si descargaste un ZIP, descomprime el nuevo y copia dentro tu carpeta `datos/`.

**Si la instalaste antes del 15 de octubre de 2026:** los scripts pasaron a la carpeta `mac/`. Vuelve a ejecutar `mac/instalar.sh` y, si usas el icono del Dock, `mac/crear-lanzador.sh`.

## Si algo falla

| Qué pasa | Qué hacer |
|---|---|
| *"El python3 de Homebrew no encuentra numpy"* | `brew reinstall numpy` y vuelve a ejecutar `mac/instalar.sh` |
| *"Node es antiguo"* | `brew upgrade node` |
| *"codex X: el motor está probado con 0.158.0"* y falla al generar | `npm install -g @openai/codex@0.158.0` |
| Ajustes marca una herramienta en rojo | Vuelve a ejecutar `mac/instalar.sh` y lee lo que dice |

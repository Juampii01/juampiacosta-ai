> **Carrusel Creator Pro · Sistema de Forja IA.** Sistema listo para replicar de la biblioteca [Forja IA](https://www.forjaia.com), adaptado por Juampi ([@juampiiacosta.ia](https://www.instagram.com/juampiiacosta.ia)). La guía paso a paso para instalarlo, publicarlo y vendérselo a un cliente está en [forjaia.com/sistemas](https://www.forjaia.com/sistemas).

<div align="center">

# Carrusel Creator Pro

**Convierte carruseles virales de Instagram (o tu propio guion) en carruseles con tu marca, listos para subir.**

![Mac](https://img.shields.io/badge/Mac-listo-000000?logo=apple&logoColor=white)
![Windows](https://img.shields.io/badge/Windows%2010%20%2F%2011-listo-0078D4)
![Next.js](https://img.shields.io/badge/Next.js-16-000000?logo=nextdotjs&logoColor=white)
![Python](https://img.shields.io/badge/Python-3-3776AB?logo=python&logoColor=white)
![Codex](https://img.shields.io/badge/Codex-im%C3%A1genes-10A37F)
![Claude](https://img.shields.io/badge/Claude-textos-D97757?logo=anthropic&logoColor=white)

Corre en tu equipo, en el navegador. Codex genera las imágenes con tu plan de ChatGPT, Claude escribe los textos y la app te deja los JPG limpios para publicar.

<table>
  <tr>
    <th>📥 El carrusel viral de referencia</th>
    <th>✨ El que hace la app con tu marca</th>
  </tr>
  <tr>
    <td><img src="docs/img/carrusel-original.jpg" alt="Los 6 slides del carrusel original de Instagram, en inglés y con fondo claro" width="100%"></td>
    <td><img src="docs/img/carrusel-ejemplo.jpg" alt="Los 6 slides del carrusel hecho con la app: portada, cuatro pasos y cierre con «Comenta ORO»" width="100%"></td>
  </tr>
  <tr>
    <td align="center"><sub>Original de Instagram (@sebastianhardy_), 6 slides</sub></td>
    <td align="center"><sub>La misma idea, slide a slide, con la cara, el color y el ángulo del cliente. Tal como sale: sin pie ni contador</sub></td>
  </tr>
</table>

</div>

---

## Qué hace

- 📥 **Copia la estructura de un carrusel que ya funciona**: pegas el link y la app baja sus slides.
- ✍️ **Escribe tu versión**: Claude redacta la ficha de cada slide con tu ángulo, sin inventar cifras.
- 🎨 **Genera los slides con tu cara y tu estilo**: Codex los hace en una sola llamada.
- 🎬 **Anima un slide** si quieres: oleadas, latidos, saltos de iconos (lo prepara Claude).
- ✅ **Los deja listos para subir**: JPG 1080×1350 sin metadatos de AI, con tu ubicación, en un ZIP con la descripción y 5 variaciones.
- 👥 **Varios clientes**: cada uno con su marca, sus fotos y su biblioteca de carruseles.

## Cómo funciona

```mermaid
flowchart LR
    A["🔗 Link de Instagram<br/>o tu guion"] --> B["✍️ Ficha<br/><i>Claude</i>"]
    B --> C["🔍 Comprobación<br/><i>el motor</i>"]
    C --> D["🎨 Generar slides<br/><i>Codex</i>"]
    D --> E["👀 Revisión<br/><i>tú</i>"]
    E -->|"algo falla"| F["🔧 Corregir 1 slide"]
    F --> E
    E --> G["📝 Descripción<br/><i>Claude</i>"]
    G --> H["🎬 Vídeo<br/><i>opcional</i>"]
    H --> I["📦 Cerrar: JPG limpios + ZIP"]
```

Hay dos paradas tuyas, la ficha y el resultado: hoy salen bien a la primera unos 5 de cada 7 slides.

## Úsala desde la app o desde Claude

```mermaid
flowchart TB
    U["🧑 Tú"] --> APP["🖥️ La app<br/>carrusel.localhost:3000"]
    U --> CL["🤖 Claude Code<br/>en la carpeta"]
    APP --> M["⚙️ El motor"]
    CL --> M
    M --> MAC["🍎 mac/motor<br/>zsh"]
    M --> WIN["🪟 windows/motor<br/>Python + Pillow"]
    MAC & WIN --> COM["🧩 motor/ común<br/>fichas, prompts, vídeo con numpy"]
    COM --> D["📁 datos/perfiles/&lt;cliente&gt;<br/>marca · fichas · carruseles"]
    D --> APP
```

Lo que haga Claude sin abrir la app **también aparece en la app**: el motor escribe en las mismas carpetas y avisa de lo que está haciendo. Nunca corren dos generaciones a la vez.

## Mac y Windows

| | 🍎 Mac | 🪟 Windows 10 / 11 |
|---|---|---|
| **Guía de instalación** | [`mac/install.md`](mac/install.md) | [`windows/install.md`](windows/install.md) |
| **Instalar** | `mac/instalar.sh` | `powershell -ExecutionPolicy Bypass -File .\windows\instalar.ps1` |
| **Arrancar** | `mac/arrancar.sh` o el icono del Dock | Acceso directo del escritorio o `windows\arrancar.cmd` |
| **Herramientas** | Homebrew: Node, ffmpeg, exiftool, Python y numpy | winget: Node, ffmpeg, ExifTool, Python y Git; pip: Pillow y numpy |
| **Motor** | `mac/motor/carrusel.sh` | `windows\motor\carrusel.py` |
| **Pruebas sin gasto** | `mac/motor/pruebas/correr.sh` | `python windows\motor\pruebas\correr.py` |

**Lo más fácil:** abre Claude Code dentro de la carpeta y dile *"instálame esta app"*. Sigue la guía de tu sistema y te dice qué tienes que hacer tú (por ejemplo, `codex login`).

## Lo que necesitas

| | |
|---|---|
| 🤖 **Codex CLI** con tu cuenta de ChatGPT | Genera las imágenes. Bloquea en torno a **60 imágenes al día por cuenta** (medido, no publicado): unos 5 o 6 carruseles. La app lleva la cuenta |
| ✍️ **Claude Code** con tu cuenta | Redacta fichas y descripciones |
| 🔑 **Clave de [ScrapeCreators](https://scrapecreators.com)** | Baja los carruseles originales (1 crédito cada uno). Con tu propio guion no hace falta |
| 📸 **Tus fotos** | De 1 a 3 tuyas y de 1 a 3 referencias de estilo |

Cada persona usa **sus propias cuentas y su propia marca**. Todo lo tuyo (fotos, fichas, carruseles, claves y `datos/usuario.md`, donde Claude apunta tu nombre y tus gustos) vive en `datos/`, que nunca se sube a GitHub.

## Estructura

```
app/       la interfaz (Next.js 16) y su API local — la misma en Mac y Windows
motor/     lo común: fichas, descarga, vídeo (numpy), prompts y reglas
mac/       motor de Mac, instalador, arranque e icono del Dock
windows/   motor de Windows, instalador y arranque
datos/     lo tuyo (fuera de git): perfiles/<cliente>/, cupo, ajustes y usuario.md
```

[`CLAUDE.md`](CLAUDE.md) es el manual de la app para Claude, y [`motor/REGLAS.md`](motor/REGLAS.md), las reglas del contenido.

## Lo que no hace

- No acelera a Codex: cada carrusel tarda de 5 a 12 minutos.
- No publica en Instagram.
- No funciona sin Codex conectado.
- No sustituye tu ojo: hay que mirar el resultado antes de cerrar.
- No se puede subir a Vercel tal cual: Codex y Claude Code se usan con la sesión de tu plan (sin pagar API) y los carruseles se guardan en tu disco.

## Metadatos

Al cerrar, cada imagen se recodifica y cada vídeo se reempaqueta, y se les borran todos los metadatos, incluido el manifiesto de contenido de AI que añade el generador. Como único dato se escribe la ubicación del cliente (por defecto Newark, New Jersey; se cambia en Branding). La marca de agua invisible en los píxeles se degrada con la recodificación, pero no hay forma de confirmar que desaparece. Úsalo bajo tu criterio y el de las normas de la plataforma donde publiques.

## Versiones probadas

Codex CLI **0.158.0** (modelo `gpt-5.6-terra`) y Claude Code **2.1**. Los instaladores ponen esa versión de Codex y avisan si tienes otra.

import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import { cliente } from "@/lib/motor";

export const dynamic = "force-dynamic";

const tipos: Record<string, string> = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".mp4": "video/mp4", ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8" };

/** Sirve un archivo de la carpeta de datos (imágenes de los slides, del original, del kit de marca). Solo dentro de datos/. */
export async function GET(req: Request) {
  const ruta = new URL(req.url).searchParams.get("ruta") ?? "";
  const absoluta = path.resolve(cliente(), ruta);
  if (!absoluta.startsWith(path.resolve(cliente()) + path.sep)) return NextResponse.json({ error: "Ruta no permitida" }, { status: 400 });
  try {
    const [bytes, st] = [await fs.readFile(absoluta), await fs.stat(absoluta)];
    const tipo = tipos[path.extname(absoluta).toLowerCase()] ?? "application/octet-stream";
    // vídeos (slides en movimiento): el navegador pide trozos con Range para reproducir y repetir en bucle
    const rango = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get("range") ?? "");
    if (rango && (rango[1] || rango[2])) {
      const ini = rango[1] ? Number(rango[1]) : Math.max(0, bytes.length - Number(rango[2]));
      const fin = rango[1] && rango[2] ? Math.min(Number(rango[2]), bytes.length - 1) : bytes.length - 1;
      if (ini >= bytes.length || ini > fin) return new NextResponse(null, { status: 416, headers: { "Content-Range": `bytes */${bytes.length}` } });
      return new NextResponse(bytes.subarray(ini, fin + 1), { status: 206, headers: { "Content-Type": tipo, "Content-Range": `bytes ${ini}-${fin}/${bytes.length}`, "Accept-Ranges": "bytes", "Content-Length": String(fin - ini + 1), "Cache-Control": "no-store" } });
    }
    return new NextResponse(bytes, { headers: { "Content-Type": tipo, "Accept-Ranges": "bytes", "Cache-Control": "no-store", "Last-Modified": st.mtime.toUTCString() } });
  } catch { return NextResponse.json({ error: "No existe" }, { status: 404 }); }
}

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Volume2, VolumeX, X } from "lucide-react";
import { Sfx, iniciarSonidos } from "@/lib/sonidos";
import { recargarSinIntro } from "@/lib/navegacion";
import { useConexion, type Herramienta } from "@/lib/useConexion";

/* Primer arranque: deja la marca y las conexiones configuradas en 4 bloques.
   Guarda en los mismos sitios que Branding y Ajustes (/api/marca, /api/marca/foto, /api/ajustes). */

type Opcion = { v: string; t: string; e?: string };
type Ajustes = { codex_ok: boolean; claude_ok: boolean; claude_instalado: boolean; clave_puesta: boolean; creditos: number | null; creditos_error?: string; herramientas: Record<string, boolean> ; windows?: boolean};

// modo "inicial": primera vez del equipo (marca + conexiones). Modo "cliente": un cliente nuevo, sin las conexiones (son del equipo).
const BLOQUES_INICIAL = ["Tú", "Tu marca", "Tu personaje", "Conexiones"];
const BLOQUES_CLIENTE = ["El cliente", "Su marca", "Su personaje", "Publicación"];
// cada paso: su bloque (0-3)
const PASOS_TODOS = [
  { id: "nombre", b: 0 }, { id: "handle", b: 0 },
  { id: "color", b: 1 }, { id: "angulo", b: 1 },
  { id: "fotos", b: 2 }, { id: "estilo", b: 2 }, { id: "ropa", b: 2 },
  { id: "clave", b: 3 }, { id: "conexiones", b: 3 }, { id: "ubicacion", b: 3 },
] as const;

const COLORES: (Opcion & { hex: string })[] = [
  { v: "#0070F8", hex: "#0070F8", t: "Azul Forja" }, { v: "#1A79FB", hex: "#1A79FB", t: "Azul eléctrico" },
  { v: "#10B981", hex: "#10B981", t: "Verde" }, { v: "#7C3AED", hex: "#7C3AED", t: "Morado" },
  { v: "#F97316", hex: "#F97316", t: "Naranja" }, { v: "otro", hex: "", t: "Otro color" },
];
const ANGULOS: Opcion[] = [
  { v: "vender sistemas de AI a empresas en USA, para latinos que viven en Estados Unidos", t: "Vender AI a empresas en USA", e: "💼" },
  { v: "enseñar a emprendedores latinos a usar AI en su negocio", t: "Emprendedores latinos", e: "🚀" },
  { v: "ayudar a creadores de contenido a crecer con AI", t: "Creadores de contenido", e: "🎬" },
  { v: "otro", t: "Otro: lo escribo yo", e: "✍️" },
];
const ROPAS: Opcion[] = [
  { v: "traje azul marino y camisa blanca, sin corbata", t: "Traje azul marino y camisa blanca", e: "🤵" },
  { v: "camisa casual de botones, lisa", t: "Camisa casual", e: "👔" },
  { v: "sudadera lisa de color oscuro", t: "Sudadera lisa", e: "🧥" },
  { v: "otro", t: "Otra: la escribo yo", e: "✍️" },
];
const UBICACIONES = [
  { v: "newark", t: "Newark, NJ", e: "🗽", u: { ciudad: "Newark", estado: "New Jersey", pais: "United States", codigo: "US", lat: 40.7357, lon: -74.1724 } },
  { v: "miami", t: "Miami, FL", e: "🌴", u: { ciudad: "Miami", estado: "Florida", pais: "United States", codigo: "US", lat: 25.7617, lon: -80.1918 } },
  { v: "houston", t: "Houston, TX", e: "🤠", u: { ciudad: "Houston", estado: "Texas", pais: "United States", codigo: "US", lat: 29.7604, lon: -95.3698 } },
  { v: "la", t: "Los Ángeles, CA", e: "🌉", u: { ciudad: "Los Angeles", estado: "California", pais: "United States", codigo: "US", lat: 34.0522, lon: -118.2437 } },
  { v: "nyc", t: "Nueva York, NY", e: "🏙️", u: { ciudad: "New York", estado: "New York", pais: "United States", codigo: "US", lat: 40.7128, lon: -74.006 } },
  { v: "chicago", t: "Chicago, IL", e: "🌬️", u: { ciudad: "Chicago", estado: "Illinois", pais: "United States", codigo: "US", lat: 41.8781, lon: -87.6298 } },
];

function confeti(n = 90) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colores = ["#0070f8", "#4da3ff", "#8cc6ff", "#ffffff", "#ffd166"];
  for (let i = 0; i < n; i++) {
    const p = document.createElement("i");
    p.className = "cm-confetti";
    const s = 6 + Math.random() * 6;
    Object.assign(p.style, { left: `${Math.random() * 100}vw`, width: `${s}px`, height: `${s * 0.45}px`, background: colores[i % colores.length], animationDuration: `${2.2 + Math.random() * 1.8}s`, animationDelay: `${Math.random() * 0.4}s` });
    document.body.appendChild(p);
    setTimeout(() => p.remove(), 4800);
  }
}

export function Bienvenida() {
  const router = useRouter();
  const [paso, setPaso] = useState(-1); // -1 portada · 0-10 preguntas · 11 guardando · 12 listo
  const [mudo, setMudo] = useState(false);
  const [error, setError] = useState("");
  const [nombre, setNombre] = useState("");
  const [handle, setHandle] = useState("");
  const [color, setColor] = useState("");
  const [colorOtro, setColorOtro] = useState("#0070F8");
  const [angulo, setAngulo] = useState("");
  const [anguloOtro, setAnguloOtro] = useState("");
  const [ropa, setRopa] = useState("");
  const [ropaOtra, setRopaOtra] = useState("");
  const [fotos, setFotos] = useState<string[]>([]);
  const [estilos, setEstilos] = useState<string[]>([]); // referencias de estilo, de 1 a 3
  const [subiendo, setSubiendo] = useState(false);
  const [encima, setEncima] = useState(false);
  const [clave, setClave] = useState("");
  const [aj, setAj] = useState<Ajustes | null>(null);
  const [comprobando, setComprobando] = useState(false);
  const [ubicacion, setUbicacion] = useState("newark");
  const [modo, setModo] = useState<"inicial" | "cliente">("inicial");
  const [perfilId, setPerfilId] = useState("");
  const titulo = useRef<HTMLHeadingElement>(null);
  const esCliente = modo === "cliente";
  const PASOS = esCliente ? PASOS_TODOS.filter((p) => p.id !== "clave" && p.id !== "conexiones") : PASOS_TODOS;
  const BLOQUES = esCliente ? BLOQUES_CLIENTE : BLOQUES_INICIAL;
  /** El texto según a quién se le habla: a quien configura su marca, o sobre un cliente. */
  const t = (inicial: string, deCliente: string) => (esCliente ? deCliente : inicial);

  // lo que ya hubiera (si se repite la bienvenida, no se empieza de cero)
  useEffect(() => {
    iniciarSonidos();
    let vivo = true;
    fetch("/api/bienvenida", { cache: "no-store" }).then((r) => r.json()).then((b: { modo: "inicial" | "cliente"; perfil: string; nombre: string }) => {
      if (!vivo) return;
      setModo(b.modo); setPerfilId(b.perfil);
      if (b.modo === "cliente" && b.nombre && b.nombre !== "Nuevo cliente") setNombre(b.nombre); // el nombre provisional no se precarga
    }).catch(() => {});
    fetch("/api/marca", { cache: "no-store" }).then((r) => r.json()).then((d: { marca: Record<string, string>; fotos: string[]; estilos?: string[] }) => {
      if (!vivo) return;
      setMudo(Sfx.enSilencio());
      const m = d.marca;
      if (m.nombre) setNombre((n) => n || m.nombre);
      if (m.handle && m.handle !== "@tucuenta") setHandle(m.handle);
      if (m.azul) { const c = COLORES.find((x) => x.hex.toLowerCase() === m.azul.toLowerCase()); if (c) setColor(c.v); else { setColor("otro"); setColorOtro(m.azul); } }
      if (m.angulo) { if (ANGULOS.some((a) => a.v === m.angulo)) setAngulo(m.angulo); else { setAngulo("otro"); setAnguloOtro(m.angulo); } }
      if (m.ropa) { if (ROPAS.some((r) => r.v === m.ropa)) setRopa(m.ropa); else { setRopa("otro"); setRopaOtra(m.ropa); } }
      setFotos(d.fotos ?? []);
      setEstilos(d.estilos ?? []);
    }).catch(() => {});
    return () => { vivo = false; };
  }, []);

  const idPaso = paso >= 0 && paso < PASOS.length ? PASOS[paso].id : null;
  const bloque = idPaso ? PASOS[paso].b : paso >= PASOS.length ? 4 : 0;

  const comprobar = useCallback(async () => {
    setComprobando(true);
    try { setAj((await (await fetch("/api/ajustes", { cache: "no-store" })).json()) as Ajustes); } finally { setComprobando(false); }
  }, []);
  useEffect(() => { if (idPaso === "conexiones" && !aj) void Promise.resolve().then(comprobar); }, [idPaso, aj, comprobar]);
  useEffect(() => { titulo.current?.focus(); }, [paso]);

  const valido = (): string => {
    switch (idPaso) {
      case "nombre": return nombre.trim() ? "" : t("Escribe tu nombre", "Escribe el nombre del cliente");
      case "handle": return /^@?[A-Za-z0-9._]{2,30}$/.test(handle.trim()) ? "" : "Escribe tu cuenta, por ejemplo @tucuenta";
      case "color": return !color ? "Elige un color" : color === "otro" && !/^#[0-9a-fA-F]{6}$/.test(colorOtro) ? "Elige el color" : "";
      case "angulo": return !angulo ? "Elige una opción" : angulo === "otro" && !anguloOtro.trim() ? "Escribe a quién le hablas" : "";
      case "fotos": return fotos.length >= 1 ? "" : t("Sube al menos una foto tuya", "Sube al menos una foto");
      case "estilo": return estilos.length >= 1 ? "" : "Sube al menos una imagen de referencia";
      case "ropa": return !ropa ? "Elige una opción" : ropa === "otro" && !ropaOtra.trim() ? "Escribe la ropa" : "";
      default: return "";
    }
  };

  async function guardarClave(): Promise<boolean> {
    if (!clave.trim()) return true; // ya puesta o se deja para luego
    await fetch("/api/ajustes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scrapecreators_key: clave.trim() }) });
    const d = (await (await fetch("/api/ajustes", { cache: "no-store" })).json()) as Ajustes;
    setAj(d);
    if (d.creditos_error) { setError(d.creditos_error); return false; }
    return true;
  }

  async function terminar() {
    setPaso(PASOS.length);
    const inicio = Date.now();
    const marca = {
      nombre: nombre.trim(), handle: handle.trim().startsWith("@") ? handle.trim() : "@" + handle.trim(),
      azul: (color === "otro" ? colorOtro : color).toUpperCase(), angulo: angulo === "otro" ? anguloOtro.trim() : angulo,
      ropa: ropa === "otro" ? ropaOtra.trim() : ropa,
    };
    const u = UBICACIONES.find((x) => x.v === ubicacion)?.u;
    try {
      const r1 = await fetch("/api/marca", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(marca) });
      if (!r1.ok) throw new Error((await r1.json()).error ?? "No se pudo guardar la marca");
      await fetch("/api/ajustes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ubicacion: u }) });
      if (perfilId) await fetch("/api/perfiles", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accion: "renombrar", id: perfilId, nombre: nombre.trim() }) });
      await fetch("/api/bienvenida", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ hecha: true, modo }) });
    } catch (e) { setPaso(PASOS.length - 1); setError((e as Error).message); return; }
    await new Promise((r) => setTimeout(r, Math.max(0, 1400 - (Date.now() - inicio))));
    setPaso(PASOS.length + 1);
    Sfx.success(); confeti();
  }

  async function siguiente() {
    setError("");
    if (paso === -1) { Sfx.advance(); setPaso(0); return; }
    const e = valido();
    if (e) { setError(e); return; }
    if (idPaso === "clave" && !(await guardarClave())) return;
    if (paso === PASOS.length - 1) { void terminar(); return; }
    Sfx.advance();
    setPaso(paso + 1);
  }
  /** Salir sin terminar (solo con clientes): un cliente nuevo vacío va a la papelera y se vuelve al cliente de antes. */
  async function cancelar() {
    Sfx.click();
    await fetch("/api/perfiles", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accion: "cancelar" }) }).catch(() => {});
    recargarSinIntro("/");
  }
  function atras() { if (paso > 0) { Sfx.click(); setError(""); setPaso(paso - 1); } }

  function elegir(fn: (v: string) => void, v: string) {
    Sfx.select(); fn(v); setError("");
  }

  async function subir(lista: FileList | null, tipo: "personaje" | "tipografia") {
    if (!lista?.length) return;
    setSubiendo(true); setError("");
    try {
      const fd = new FormData();
      fd.append("tipo", tipo);
      for (const f of Array.from(lista).slice(0, 3)) fd.append("archivos", f);
      const r = await fetch("/api/marca/foto", { method: "POST", body: fd });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "No se pudo subir");
      const m = d.marca as Record<string, string>;
      const separar = (v?: string) => (v ?? "").split(",").map((f) => f.trim()).filter(Boolean);
      if (tipo === "personaje") setFotos(separar(m.fotos));
      else setEstilos(separar(m.tipografia));
      Sfx.select();
      if (d.fallidos?.length) setError(`No se pudo leer como imagen: ${d.fallidos.join(", ")}. Las demás se guardaron.`);
    } catch (e) { setError((e as Error).message); } finally { setSubiendo(false); }
  }

  /** Borrar una foto subida por error (o una referencia de estilo): se quita del disco y de la marca. */
  async function borrarFoto(ruta: string) {
    Sfx.click(); setError("");
    const r = await fetch("/api/marca/foto", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ruta }) });
    if (!r.ok) { setError((await r.json()).error ?? "No se pudo borrar"); return; }
    if (estilos.includes(ruta)) setEstilos((es) => es.filter((x) => x !== ruta)); else setFotos((fs) => fs.filter((x) => x !== ruta));
  }

  // opciones de la pantalla actual, para los atajos de teclado 1-6
  const opciones: { lista: Opcion[]; fijar: (v: string) => void } | null =
    idPaso === "color" ? { lista: COLORES, fijar: setColor } : idPaso === "angulo" ? { lista: ANGULOS, fijar: setAngulo }
    : idPaso === "ropa" ? { lista: ROPAS, fijar: setRopa } : idPaso === "ubicacion" ? { lista: UBICACIONES, fijar: setUbicacion } : null;

  useEffect(() => {
    const tecla = (e: KeyboardEvent) => {
      // con el foco en un botón, Enter ya lo pulsa el navegador: si además avanzáramos, haría dos cosas a la vez
      const enCampo = e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLButtonElement;
      if (e.key === "Enter" && !enCampo && !e.shiftKey) { e.preventDefault(); void siguiente(); return; }
      if (opciones && !(e.target instanceof HTMLInputElement) && /^[1-9]$/.test(e.key)) {
        const o = opciones.lista[Number(e.key) - 1];
        if (o) elegir(opciones.fijar, o.v);
      }
    };
    window.addEventListener("keydown", tecla); return () => window.removeEventListener("keydown", tecla);
  });

  const segmentos = BLOQUES.map((_, i) => {
    if (bloque > i) return 100;
    if (bloque < i || !idPaso) return 0;
    const delBloque = PASOS.filter((p) => p.b === i);
    const pos = delBloque.findIndex((p) => p.id === idPaso);
    return Math.round(((pos + 1) / delBloque.length) * 100);
  });

  const img = (ruta: string) => `/api/archivo?ruta=${encodeURIComponent(`marca/${ruta}`)}`;
  const tarjetas = (lista: Opcion[], valor: string, fijar: (v: string) => void, emoji = true) => (
    <div className={`cm-opts${emoji ? " cm-opts--emoji" : ""}`} role="radiogroup">
      {lista.map((o, i) => (
        <button key={o.v} type="button" role="radio" aria-checked={valor === o.v} className={`cm-opt${valor === o.v ? " is-picked" : ""}`} onClick={() => elegir(fijar, o.v)}>
          {"hex" in o ? <span className="cm-swatch" style={{ background: (o as { hex: string }).hex || "conic-gradient(red, yellow, lime, cyan, blue, magenta, red)" }} /> : o.e && <span className="cm-opt__e">{o.e}</span>}
          <span>{o.t}</span>
          <span className="cm-opt__k">{i + 1}</span>
        </button>
      ))}
    </div>
  );

  const pregunta = () => {
    switch (idPaso) {
      case "nombre": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("¿Cómo te llamas?", "¿Cómo se llama el cliente?")}</h2>
        {esCliente && <p className="cm-q__help">Su nombre o el de su marca. Es como lo verás en el selector de clientes.</p>}
        <input className={`cm-input${error ? " is-bad" : ""}`} autoFocus value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder={t("Tu nombre", "Nombre del cliente")} autoComplete={esCliente ? "off" : "given-name"} />
      </>);
      case "handle": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{esCliente ? `¿Cuál es la cuenta de Instagram de ${nombre.trim() || "el cliente"}?` : nombre ? `${nombre.split(" ")[0]}, ¿cuál es tu cuenta de Instagram?` : "¿Cuál es tu cuenta de Instagram?"}</h2>
        <p className="cm-q__help">{t("Claude la usa en las descripciones de tus carruseles.", "Claude la usa en las descripciones de sus carruseles.")}</p>
        <input className={`cm-input${error ? " is-bad" : ""}`} autoFocus value={handle} onChange={(e) => setHandle(e.target.value.replace(/\s/g, ""))} placeholder="@tucuenta" autoCapitalize="none" />
      </>);
      case "color": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("¿Cuál es el color de tu marca?", "¿Cuál es el color de su marca?")}</h2>
        <p className="cm-q__help">Va en los titulares y los detalles de cada slide.</p>
        {tarjetas(COLORES, color, setColor)}
        {color === "otro" && <div className="cm-field"><label htmlFor="cm-color">Tu color</label><input id="cm-color" type="color" className="cm-input" style={{ padding: 6 }} value={colorOtro} onChange={(e) => setColorOtro(e.target.value.toUpperCase())} /></div>}
      </>);
      case "angulo": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("¿A quién le hablas?", "¿A quién le habla?")}</h2>
        <p className="cm-q__help">Claude lo usa para escribir cada carrusel y su descripción.</p>
        {tarjetas(ANGULOS, angulo, setAngulo)}
        {angulo === "otro" && <textarea className="cm-input" rows={2} autoFocus value={anguloOtro} onChange={(e) => setAnguloOtro(e.target.value)} placeholder="Por ejemplo: ayudar a dueños de restaurantes a automatizar con AI" />}
      </>);
      case "fotos": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("Sube de 1 a 3 fotos tuyas", `Sube de 1 a 3 fotos de ${nombre.trim() || "el cliente"}`)}</h2>
        <p className="cm-q__help">{t("De frente, con buena luz y de distintos ángulos. Codex las usa para que en cada slide salgas tú.", "De frente, con buena luz y de distintos ángulos. Codex las usa para que salga en cada slide.")}</p>
        {fotos.length > 0 && <div className="cm-thumbs">{fotos.map((f) => (
          <div key={f} className="cm-thumb">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img(f)} alt="Tu foto" />
            <button type="button" className="cm-thumb__x" onClick={() => void borrarFoto(f)} aria-label="Borrar esta foto" title="Borrar esta foto"><X size={16} /></button>
          </div>
        ))}</div>}
        <Zona multiple onFiles={(l) => subir(l, "personaje")} subiendo={subiendo} encima={encima} setEncima={setEncima} texto={fotos.length ? "Añadir o cambiar fotos (máximo 3)" : "Arrastra tus fotos aquí"} />
      </>);
      case "estilo": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>Sube de 1 a 3 referencias de estilo</h2>
        <p className="cm-q__help">Portadas o miniaturas que te gusten: Codex copia de ahí la letra y el acabado.</p>
        {estilos.length > 0 && <div className="cm-thumbs">{estilos.map((f) => (
          <div key={f} className="cm-thumb">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img(f)} alt="Tu referencia" />
            <button type="button" className="cm-thumb__x" onClick={() => void borrarFoto(f)} aria-label="Borrar esta referencia" title="Borrar esta referencia"><X size={16} /></button>
          </div>
        ))}</div>}
        <Zona multiple onFiles={(l) => subir(l, "tipografia")} subiendo={subiendo} encima={encima} setEncima={setEncima} texto={estilos.length ? "Añadir o cambiar referencias (máximo 3)" : "Arrastra las imágenes aquí"} />
      </>);
      case "ropa": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("¿Qué ropa llevas en los slides?", "¿Qué ropa lleva en los slides?")}</h2>
        <p className="cm-q__help">{t("Siempre la misma, para que tu marca se reconozca.", "Siempre la misma, para que su marca se reconozca.")}</p>
        {tarjetas(ROPAS, ropa, setRopa)}
        {ropa === "otro" && <input className="cm-input" autoFocus value={ropaOtra} onChange={(e) => setRopaOtra(e.target.value)} placeholder="Por ejemplo: polo negro con el logo" />}
      </>);
      case "clave": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>Tu clave de ScrapeCreators</h2>
        <p className="cm-q__help">Sirve para descargar los carruseles virales que copias (1 crédito cada uno). La sacas en scrapecreators.com. Si aún no la tienes, deja el campo vacío y la pones luego en Ajustes.</p>
        <input className={`cm-input${error ? " is-bad" : ""}`} value={clave} onChange={(e) => setClave(e.target.value)} placeholder={aj?.clave_puesta ? "Ya tienes una clave guardada" : "Pega tu clave"} autoComplete="off" spellCheck={false} />
        {aj?.creditos != null && !error && <p className="cm-ok-txt">✓ Clave válida · {aj.creditos} créditos</p>}
      </>);
      case "conexiones": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>Codex y Claude Code</h2>
        <p className="cm-q__help">Codex genera las imágenes con tu plan de ChatGPT; Claude Code escribe las fichas y las descripciones con tu suscripción de Claude. Pulsa el botón y entra con tu cuenta en el navegador.</p>
        {!aj ? <div className="cm-wait"><div className="cm-wait__spin" /><p className="cm-wait__text">Comprobando…</p></div> : (<>
          <FilaConexion ok={aj.codex_ok} nombre="Codex" si="Conectado a tu cuenta de ChatGPT" no="Sin sesión de ChatGPT" herramienta="codex" alConectar={comprobar} />
          {aj.claude_instalado
            ? <FilaConexion ok={aj.claude_ok} nombre="Claude Code" si="Conectado a tu cuenta de Claude" no="Sin sesión de Claude" herramienta="claude" alConectar={comprobar} />
            : <Fila ok={false} nombre="Claude Code" si="" no="No está instalado. En la carpeta de la app, ejecuta:" orden={aj.windows ? "powershell -ExecutionPolicy Bypass -File .\\windows\\instalar.ps1" : "mac/instalar.sh"} />}
          {Object.entries(aj.herramientas).some(([, v]) => !v) && <Fila ok={false} nombre={`Faltan: ${Object.entries(aj.herramientas).filter(([, v]) => !v).map(([k]) => k).join(", ")}`} no="En la carpeta de la app, ejecuta:" orden={aj.windows ? "powershell -ExecutionPolicy Bypass -File .\\windows\\instalar.ps1" : "mac/instalar.sh"} si="" />}
          <button type="button" className="cm-back" style={{ justifySelf: "center" }} disabled={comprobando} onClick={() => { Sfx.click(); void comprobar(); }}>{comprobando ? "Comprobando…" : "↻ Volver a comprobar"}</button>
          {(!aj.codex_ok || !aj.claude_ok) && <p className="cm-q__help" style={{ textAlign: "center", marginTop: 0 }}>Puedes seguir y conectarlo después: sin Codex no se puede generar.</p>}
        </>)}
      </>);
      case "ubicacion": return (<>
        <h2 className="cm-q__title" tabIndex={-1} ref={titulo}>{t("¿Dónde publicas?", "¿Dónde publica?")}</h2>
        <p className="cm-q__help">Al cerrar cada carrusel se borran los metadatos de AI y se escribe esta ubicación. La puedes cambiar en Ajustes.</p>
        {tarjetas(UBICACIONES, ubicacion, setUbicacion)}
      </>);
      default: return null;
    }
  };

  const nombreCorto = nombre.trim().split(" ")[0];

  return (
    <div className="cmb">
      <div className="cm-pop__card" key={paso < 0 ? "portada" : paso >= PASOS.length ? `fin${paso}` : "quiz"}>
        {esCliente && paso === -1 && (
          <button type="button" className="cm-icon-btn" style={{ position: "absolute", top: 12, right: 12 }} onClick={() => void cancelar()} aria-label="Cancelar y volver" title="Cancelar y volver"><X size={20} /></button>
        )}
        {paso === -1 && (
          <div>
            <div className="cm-logo">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/forja.png" alt="Forja IA" />
            </div>
            <span className="cm-eyebrow">Forja IA · Carrusel Creator Pro</span>
            <h1 className="cm-pop__title" tabIndex={-1}>{t("Bienvenido a tu fábrica de carruseles", "Nuevo cliente")}</h1>
            <p className="cm-pop__sub">{t("Deja tu marca lista en 3 minutos y crea tu primer carrusel.", "Deja su marca lista en 2 minutos. Sus carruseles quedan aparte de los demás clientes.")}</p>
            <ul className="cm-bullets">
              <li><span>🎨</span>{t("Tu marca: cuenta, color y a quién le hablas", "Su marca: cuenta, color y a quién le habla")}</li>
              <li><span>📸</span>{t("Tus fotos, para salir en cada slide", "Sus fotos, para que salga en cada slide")}</li>
              <li><span>{esCliente ? "📍" : "🔌"}</span>{t("Tus conexiones: Codex, Claude y ScrapeCreators", "Dónde publica, para los metadatos")}</li>
            </ul>
            <button type="button" className="cm-btn cm-btn--block" onClick={() => void siguiente()}>Empezar</button>
            <p className="cm-hint" style={{ marginTop: 14 }}>o pulsa Enter ↵</p>
          </div>
        )}

        {idPaso && (
          <div className="cm-quiz">
            <div className="cm-quiz__top">
              <div className="cm-quiz__segs" aria-hidden="true">{segmentos.map((w, i) => <div key={i} className="cm-seg"><i style={{ width: `${w}%` }} /></div>)}</div>
              <button type="button" className="cm-icon-btn" onClick={() => setMudo(Sfx.alternar())} aria-label={mudo ? "Activar sonido" : "Silenciar"}>{mudo ? <VolumeX size={19} /> : <Volume2 size={19} />}</button>
              {esCliente && <button type="button" className="cm-icon-btn" onClick={() => void cancelar()} aria-label="Cancelar y volver" title="Cancelar y volver"><X size={20} /></button>}
            </div>
            <div className="cm-q" key={idPaso}>
              <div className="cm-q__meta"><span className="cm-q__blk">Bloque {PASOS[paso].b + 1} · <b>{BLOQUES[PASOS[paso].b]}</b></span><span className="cm-q__count">{paso + 1} / {PASOS.length}</span></div>
              {pregunta()}
              <p className="cm-err" role="alert">{error}</p>
            </div>
            <div className="cm-quiz__nav">
              {paso > 0 && <button type="button" className="cm-back" onClick={atras}><ArrowLeft size={16} /> Atrás</button>}
              <button type="button" className="cm-btn" disabled={subiendo} onClick={() => void siguiente()}>{paso === PASOS.length - 1 ? "Terminar" : "Siguiente"}</button>
            </div>
            {opciones ? <p className="cm-hint">Pulsa 1-{opciones.lista.length} para elegir · Enter para seguir</p> : <p className="cm-hint">Enter ↵ para seguir</p>}
          </div>
        )}

        {paso === PASOS.length && (
          <div className="cm-wait"><div className="cm-wait__spin" /><span className="cm-eyebrow">Guardando</span><p className="cm-wait__text">Un momento, {nombreCorto}: estamos dejando tu marca lista…</p></div>
        )}

        {paso === PASOS.length + 1 && (
          <div className="cm-result">
            <div className="cm-result__ok" aria-hidden="true">✓</div>
            <h1 className="cm-pop__title" tabIndex={-1}>{esCliente ? `¡La marca de ${nombre.trim()} está lista!` : `¡Todo listo, ${nombreCorto}!`}</h1>
            <div className="cm-sum">
              <div><span>Cuenta</span><b>{handle.startsWith("@") ? handle : "@" + handle}</b></div>
              <div><span>Color</span><b style={{ color: color === "otro" ? colorOtro : color }}>● {color === "otro" ? colorOtro : COLORES.find((c) => c.v === color)?.t}</b></div>
              <div><span>Fotos</span><b>{fotos.length} {fotos.length === 1 ? "foto" : "fotos"} · {estilos.length} {estilos.length === 1 ? "referencia" : "referencias"}</b></div>
              {esCliente
                ? <div><span>Publica en</span><b>{UBICACIONES.find((u) => u.v === ubicacion)?.t}</b></div>
                : <div><span>Codex</span><b>{aj?.codex_ok ? "Conectado ✓" : "Pendiente"}</b></div>}
            </div>
            <button type="button" className="cm-btn cm-btn--block" onClick={() => { Sfx.advance(); router.push("/"); }}>{t("Crear mi primer carrusel", "Crear su primer carrusel")}</button>
            <button type="button" className="cm-back" onClick={() => router.push("/branding")}>{t("Revisar mi marca", "Revisar su marca")}</button>
          </div>
        )}
      </div>
    </div>
  );
}

/** Como Fila, pero si falta la sesión ofrece conectar desde aquí: abre el navegador y, al terminar, vuelve a comprobar. */
function FilaConexion({ ok, nombre, si, no, herramienta, alConectar }: { ok: boolean; nombre: string; si: string; no: string; herramienta: Herramienta; alConectar: () => void }) {
  const { fase, error, iniciar } = useConexion(herramienta, alConectar);
  return (
    <div className="cm-check">
      <span className={`cm-check__i ${ok ? "ok" : "no"}`}>{ok ? "✓" : "!"}</span>
      <span className="cm-check__t"><b>{nombre}</b>{ok ? si : no}{error && <> · {error}</>}</span>
      {!ok && (fase === "esperando"
        ? <button type="button" className="cm-back" onClick={() => { Sfx.click(); void iniciar(); }}>Esperando… ¿cerraste la ventana? Abrir de nuevo</button>
        : <button type="button" className="cm-back" onClick={() => { Sfx.click(); void iniciar(); }}>Conectar {nombre === "Codex" ? "Codex" : "Claude"}</button>)}
    </div>
  );
}

function Fila({ ok, nombre, si, no, orden }: { ok: boolean; nombre: string; si: string; no: string; orden: string }) {
  return (
    <div className="cm-check">
      <span className={`cm-check__i ${ok ? "ok" : "no"}`}>{ok ? "✓" : "!"}</span>
      <span className="cm-check__t"><b>{nombre}</b>{ok ? si : <>{no} <code>{orden}</code></>}</span>
    </div>
  );
}

function Zona({ multiple = false, onFiles, subiendo, encima, setEncima, texto }: { multiple?: boolean; onFiles: (l: FileList | null) => void; subiendo: boolean; encima: boolean; setEncima: (v: boolean) => void; texto: string }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <button type="button" className={`cm-drop${encima ? " is-over" : ""}`} disabled={subiendo}
      onClick={() => { Sfx.click(); ref.current?.click(); }}
      onDragOver={(e) => { e.preventDefault(); setEncima(true); }} onDragLeave={() => setEncima(false)}
      onDrop={(e) => { e.preventDefault(); setEncima(false); onFiles(e.dataTransfer.files); }}>
      <span style={{ fontSize: "1.8rem" }}>{subiendo ? "⏳" : "📸"}</span>
      <b>{subiendo ? "Subiendo…" : texto}</b>
      <span>o haz clic para elegir · JPG, PNG o HEIC</span>
      <input ref={ref} type="file" accept="image/*,.heic" multiple={multiple} hidden onChange={(e) => onFiles(e.target.files)} />
    </button>
  );
}

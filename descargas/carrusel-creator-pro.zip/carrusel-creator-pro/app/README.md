# Carrusel Creator Pro · app

La interfaz (Next.js) y su API local. Es la misma en Mac y en Windows: elige sola el motor de cada sistema (`mac/motor/` o `windows/motor/`).

Se arranca desde la raíz con `mac/arrancar.sh` (Mac) o `windows\arrancar.cmd` (Windows) y se abre en **http://carrusel.localhost:3000**. Todo lo demás está en el [README principal](../README.md).

# Instalar Carrusel Creator Pro en Windows

Guía paso a paso para Windows 10 y 11. Sirve para una persona y para Claude Code: si le dices a Claude *"instálame esta app"*, sigue estos mismos pasos y te avisa de lo que tienes que hacer tú.

> ¿Tienes Mac? La guía es otra: [`mac/install.md`](../mac/install.md).

## Qué necesitas

| Qué | Para qué |
|---|---|
| Windows 10 u 11 con **winget** (viene instalado) | Instala las herramientas (Node, ffmpeg, ExifTool, Python y Git) |
| Una cuenta de ChatGPT | Codex genera las imágenes con tu plan (unas 60 al día por cuenta) |
| Una cuenta de Claude | Claude Code redacta las fichas y las descripciones |
| Una clave de [ScrapeCreators](https://scrapecreators.com) | Descarga los carruseles originales (1 crédito por carrusel). Sin clave puedes trabajar con tu propio guion |
| De 1 a 3 fotos tuyas y de 1 a 3 referencias de estilo | Para que salgas tú en los slides, con tu estilo |

## Pasos

### 1. Instalador

Abre **PowerShell** dentro de la carpeta de la app y ejecuta:

```powershell
powershell -ExecutionPolicy Bypass -File .\windows\instalar.ps1
```

Instala lo que falte y deja todo listo:

- Con winget: Node (20 o más), ffmpeg, ExifTool, Python 3 y Git (Claude Code lo necesita).
- **Pillow y numpy** para Python (Pillow recorta las imágenes; numpy hace los vídeos de los slides).
- Codex CLI en la versión probada (**0.158.0**) y Claude Code, si no los tienes.
- Las dependencias de la app.
- La carpeta `datos\` con tu primer cliente (`datos\perfiles\mi_marca`). Si ya tenías datos, no los toca.
- Un acceso directo **Carrusel Creator Pro** en el escritorio, con el logo de Forja IA.

Se puede ejecutar todas las veces que quieras. Lee lo que dice al final: si algo falta, lo pone con `!`.

### 2. Conectar Codex

Si el instalador dice *"Codex sin sesión"*, ejecuta `codex login`: se abre el navegador con tu cuenta de ChatGPT. Ese paso lo haces tú (Claude no escribe contraseñas).

### 3. Arrancar

Doble clic en el acceso directo **Carrusel Creator Pro** del escritorio (o en `windows\arrancar.cmd`). Se abre sola en **http://carrusel.localhost:3000** (usa siempre esa dirección, con Chrome). Deja abierta la ventana negra mientras usas la app: al cerrarla se apaga.

### 4. Bienvenida

La primera vez sale la **bienvenida** (unos 3 minutos): tu nombre, tu cuenta de Instagram, el color, a quién le hablas, tus fotos, tus referencias de estilo, la ropa, la clave de ScrapeCreators, la comprobación de Codex y Claude, y la ubicación de los metadatos. Las claves se pegan en la app, nunca en el chat.

### 5. Que Claude te conozca

Abre Claude Code en la carpeta (`claude`). La primera vez te pregunta tu nombre y crea **`datos\usuario.md`**, donde apunta tu nombre, tus gustos y los cambios que le pidas. Así te recuerda en cada conversación. Ese archivo es tuyo: está en `datos\` y nunca se sube a GitHub.

## Comprobar que todo va

- En la app, **Ajustes → Herramientas de tu equipo**: codex, claude, ffmpeg, exiftool, python, numpy y pillow en verde.
- Pruebas del motor, sin gastar imágenes ni créditos: `python windows\motor\pruebas\correr.py` tiene que terminar con *"fallan 0"*.

## Actualizar

```powershell
git pull
powershell -ExecutionPolicy Bypass -File .\windows\instalar.ps1
```

Tus datos (`datos\`) no se tocan. Si descargaste un ZIP, descomprime el nuevo y copia dentro tu carpeta `datos\`.

**Si la instalaste antes del 15 de octubre de 2026:** los scripts pasaron a la carpeta `windows\`. Vuelve a ejecutar el instalador: rehace el acceso directo del escritorio para que apunte a `windows\arrancar.cmd`.

## Si algo falla

| Qué pasa | Qué hacer |
|---|---|
| *"No encuentro … después de instalarlo"* | Cierra PowerShell, abre una nueva (o reinicia Claude Code) y vuelve a ejecutar el instalador |
| *"'python' no responde"* | Configuración → Aplicaciones → Alias de ejecución de aplicaciones: desactiva los de python y vuelve a ejecutar el instalador |
| *"No se pudo instalar Pillow o numpy"* | `python -m pip install --user pillow numpy` y mira el error |
| *"Falta winget"* | Instala *Instalador de aplicación* desde Microsoft Store |
| *"codex X: el motor está probado con 0.158.0"* y falla al generar | `npm install -g @openai/codex@0.158.0` |
| Ajustes marca una herramienta en rojo | Vuelve a ejecutar el instalador y lee lo que dice |

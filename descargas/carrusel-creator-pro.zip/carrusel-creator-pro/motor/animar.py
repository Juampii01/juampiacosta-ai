#!/usr/bin/env python3
"""Anima un slide y lo guarda como MP4 sin sonido. Es el mismo en Mac y en Windows (numpy + ffmpeg, sin Pillow).
Sale del animador de Swift del 11-10-2026 (oleadas.swift): mismos ajustes y el mismo cálculo, paso a paso; se comprobó
fotograma a fotograma que daban lo mismo con los vídeos de ig_DdtoT-ajIUH.

Uso:
  animar.py <slide.png|jpg> <ajustes.json> <salida.mp4>
  animar.py <slide.png|jpg> <ajustes.json> --crudo     fotogramas RGB24 crudos por stdout (para comparar)

Qué hace: oleadas que salen de un centro (o recorren una ruta) por las líneas de puntos coral; los iconos dan un salto
cuando les llega la oleada; la estrella del centro late; y, si los ajustes lo piden, manos que teclean, latidos de zonas,
un objeto lanzado en parábola y estirones con la base fija. Hay un ejemplo en motor/animar_ejemplo.json.

Ajustes (JSON): centro [x,y] · velocidad (px/s) · separacion (px entre oleadas; separacion/velocidad = segundos entre oleadas)
  iconos [[x,y],...] · icono_medio (medio lado del icono, px) · linea_y [y0,y1] (franja donde están las líneas)
  excluir [[x0,y0,x1,y1],...] (zonas que no se tocan: tarjetas, textos) · estrella_radio (0 = sin latido)
  manos {imagen, rect [x0,y0,x1,y1], cada (fotogramas)} (opcional) · segundos · fps
  ruta [[x,y],...] (opcional): la oleada recorre esa línea en orden en vez de salir en círculo; los iconos van en su orden
  nitidez (6 por defecto; más alto = tramo encendido más corto, útil con separacion grande)
  latidos [{rect, amplitud, periodo}] (opcional): una zona rectangular que crece y vuelve (p. ej. la caja de la palabra clave)
  lanzar {sin, regalo [x0,y0,x1,y1], zona [x0,y0,x1,y1], altura, periodo, vuelo} (opcional): el objeto (rojo/amarillo)
    de 'regalo' sube y baja en parábola; mientras vuela, 'zona' se toma de la imagen 'sin' (el muñeco sin el objeto)
  botes [{rect, altura, periodo}] (opcional): una zona que se estira hacia arriba con la base fija (p. ej. el muñeco con los pies en el suelo)
Para que el bucle no tenga salto: segundos múltiplo de separacion/velocidad y de 1 s (latido), y segundos*fps múltiplo de 2*cada. Las rutas de imágenes de los ajustes (manos.imagen, lanzar.sin) pueden ser
relativas a la carpeta del .json.
"""
import json
import math
import os
import shutil
import subprocess
import sys

import numpy as np

BG = np.array([243.0, 241.0, 229.0])  # el crema del fondo de las líneas


def redondear(v):
    """Como .rounded() de Swift para números positivos (la mitad sube)."""
    return np.floor(v + 0.5)


def ffmpeg():
    f = shutil.which("ffmpeg")
    if not f:
        raise SystemExit("Falta ffmpeg (Mac: brew install ffmpeg · Windows: winget install Gyan.FFmpeg)")
    return f


def cargar(ruta, base):
    """La imagen en RGB, leída con ffmpeg (el mismo lector en Mac y en Windows)."""
    if not os.path.isabs(ruta):
        ruta = os.path.join(base, ruta)
    tam = subprocess.run([shutil.which("ffprobe") or "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height", "-of", "csv=p=0:s=x", ruta], stdout=subprocess.PIPE, check=True).stdout.decode().strip()
    w, h = (int(v) for v in tam.split("x")[:2])
    crudo = subprocess.run([ffmpeg(), "-v", "error", "-i", ruta, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                           stdout=subprocess.PIPE, check=True).stdout
    return np.frombuffer(crudo, np.uint8).reshape(h, w, 3).astype(np.float64)


def leer_ajustes(ruta):
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


class Animador:
    def __init__(self, slide, ajustes_ruta):
        aj = leer_ajustes(ajustes_ruta)
        base = os.path.dirname(os.path.abspath(ajustes_ruta))
        self.buf = cargar(slide, base)
        self.H, self.W = self.buf.shape[:2]
        H, W = self.H, self.W
        num = lambda k, d: float(aj.get(k, d))
        self.CX, self.CY = (float(v) for v in aj["centro"])
        self.V, self.LAM = num("velocidad", 300), num("separacion", 300)
        self.dur, self.fps = num("segundos", 6), num("fps", 30)
        self.icons = [(float(x), float(y)) for x, y in aj.get("iconos", [])]
        self.medio, self.radio = num("icono_medio", 37), num("estrella_radio", 70)
        ly0, ly1 = (int(v) for v in aj.get("linea_y", [0, H]))
        excluir = [tuple(int(v) for v in e) for e in aj.get("excluir", [])]
        self.nitidez = num("nitidez", 6)
        self.bufB, self.manos, self.cada = None, (0, 0, 0, 0), 9
        m = aj.get("manos")
        if isinstance(m, dict) and m.get("imagen"):
            self.bufB = cargar(m["imagen"], base)
            self.manos = tuple(int(v) for v in m["rect"])
            self.cada = int(m.get("cada", 9))
        self.latidos = [(tuple(int(v) for v in l["rect"]), float(l.get("amplitud", 0.04)), float(l.get("periodo", 1)))
                        for l in aj.get("latidos", [])]
        self.botes = [(tuple(int(v) for v in b["rect"]), float(b.get("altura", 10)), float(b.get("periodo", 1)))
                      for b in aj.get("botes", [])]
        self.bufSin = None
        l = aj.get("lanzar")
        if isinstance(l, dict) and l.get("sin"):
            self.bufSin = cargar(l["sin"], base)
            self.regalo = tuple(int(v) for v in l["regalo"])
            self.zonaSin = tuple(int(v) for v in l["zona"])
            self.altLanzar, self.perLanzar, self.vuelo = float(l.get("altura", 70)), float(l.get("periodo", 1)), float(l.get("vuelo", 0.7))
        self.ruta = [(float(x), float(y)) for x, y in aj.get("ruta", [])]

        # Máscara fija: puntos coral de las líneas (fuera de iconos, zonas excluidas y estrella)
        Y, X = np.mgrid[0:H, 0:W]
        self.X, self.Y = X.astype(np.float64), Y.astype(np.float64)
        r, b = self.buf[..., 0], self.buf[..., 2]
        d = np.hypot(self.X - self.CX, self.Y - self.CY)
        self.d = d
        en_icono = np.zeros((H, W), bool)
        for ix, iy in self.icons:
            en_icono |= (np.abs(self.X - ix) < self.medio + 9) & (np.abs(self.Y - iy) < self.medio + 9)
        en_excluida = np.zeros((H, W), bool)
        for x0, y0, x1, y1 in excluir:
            en_excluida |= (X >= x0) & (Y >= y0) & (X <= x1) & (Y <= y1)
        self.esLinea = ((r > 200) & (r - b > 60) & (Y > ly0) & (Y < ly1) & ~en_icono & ~en_excluida
                        & (d >= self.radio + 12))
        self.linea_y, self.linea_x = np.nonzero(self.esLinea)
        if len(self.ruta) > 1:
            self.dist_linea = self.en_ruta(self.X[self.esLinea], self.Y[self.esLinea])
            self.distIcono = [float(self.en_ruta(np.array([ix]), np.array([iy]))[0]) for ix, iy in self.icons]
        else:
            self.dist_linea = d[self.esLinea]
            self.distIcono = [math.hypot(ix - self.CX, iy - self.CY) for ix, iy in self.icons]

    def en_ruta(self, x, y):
        """Posición a lo largo de la ruta (px recorridos desde el primer punto) del punto más cercano de la línea quebrada."""
        mejor = np.full(x.shape, np.inf)
        s = np.zeros(x.shape)
        acum = 0.0
        for k in range(len(self.ruta) - 1):
            (ax, ay), (bx, by) = self.ruta[k], self.ruta[k + 1]
            dx, dy = bx - ax, by - ay
            L = math.hypot(dx, dy)
            u = np.clip(((x - ax) * dx + (y - ay) * dy) / (L * L), 0, 1)
            e = np.hypot(x - (ax + u * dx), y - (ay + u * dy))
            mas_cerca = e < mejor
            mejor = np.where(mas_cerca, e, mejor)
            s = np.where(mas_cerca, acum + u * L, s)
            acum += L
        return s

    def ola(self, d, t):
        return np.power(0.5 + 0.5 * np.cos(2 * math.pi * (d - self.V * t) / self.LAM), self.nitidez)

    @staticmethod
    def pulso(t, per):
        return math.pow(0.5 + 0.5 * math.cos(2 * math.pi * t / per), 4)

    def fotograma(self, f):
        buf, W, H = self.buf, self.W, self.H
        t = f / self.fps
        s = 1 + 0.16 * math.pow(0.5 + 0.5 * math.cos(2 * math.pi * t / (self.LAM / self.V)), 6)  # latido de la estrella
        c = buf.copy()
        if self.bufB is not None and (f // self.cada) % 2 == 1:
            m0, m1, m2, m3 = self.manos
            y0, y1, x0, x1 = max(0, m1), min(H, m3), max(0, m0), min(W, m2)
            c[y0:y1, x0:x1] = self.bufB[y0:y1, x0:x1]
        if len(self.linea_y):
            k = 0.28 + 0.72 * self.ola(self.dist_linea, t)
            ly, lx = self.linea_y, self.linea_x
            c[ly, lx] = BG + (c[ly, lx] - BG) * k[:, None]
        # salto del icono cuando le llega la oleada: se amplía desde su centro (gana el primero de la lista)
        for (ix, iy), dk in reversed(list(zip(self.icons, self.distIcono))):
            si = 1 + 0.15 * float(self.ola(np.float64(dk), t))
            if si < 1.01:
                continue
            hx = self.medio * si
            y0, y1 = max(0, math.floor(iy - hx)), min(H, math.ceil(iy + hx) + 1)
            x0, x1 = max(0, math.floor(ix - hx)), min(W, math.ceil(ix + hx) + 1)
            Xs, Ys = self.X[y0:y1, x0:x1], self.Y[y0:y1, x0:x1]
            dentro = (np.abs(Xs - ix) < hx) & (np.abs(Ys - iy) < hx)
            sx = redondear(ix + (Xs - ix) / si).astype(np.intp)
            sy = redondear(iy + (Ys - iy) / si).astype(np.intp)
            zona = c[y0:y1, x0:x1]
            zona[dentro] = buf[sy[dentro], sx[dentro]]
        # latidos: la zona crece desde su centro y vuelve
        for (r0, r1, r2, r3), amp, per in self.latidos:
            sc = 1 + amp * self.pulso(t, per)
            cx, cy = (r0 + r2) / 2, (r1 + r3) / 2
            hw, hh = (r2 - r0) / 2 * sc, (r3 - r1) / 2 * sc
            y0, y1 = max(0, math.floor(cy - hh)), min(H, math.ceil(cy + hh) + 1)
            x0, x1 = max(0, math.floor(cx - hw)), min(W, math.ceil(cx + hw) + 1)
            Xs, Ys = self.X[y0:y1, x0:x1], self.Y[y0:y1, x0:x1]
            sx = redondear(cx + (Xs - cx) / sc).astype(np.intp)
            sy = redondear(cy + (Ys - cy) / sc).astype(np.intp)
            dentro = ((np.abs(Xs - cx) < hw) & (np.abs(Ys - cy) < hh)
                      & (sx >= r0) & (sx < r2) & (sy >= r1) & (sy < r3))
            zona = c[y0:y1, x0:x1]
            zona[dentro] = buf[sy[dentro], sx[dentro]]
        # lanzar: mientras el regalo vuela, el muñeco sin regalo y el regalo dibujado más arriba
        if self.bufSin is not None:
            fase = math.fmod(t, self.perLanzar) / self.perLanzar
            h = self.altLanzar * 4 * (fase / self.vuelo) * (1 - fase / self.vuelo) if fase < self.vuelo else 0
            if h > 0.5:
                dy = int(redondear(h))
                z0, z1, z2, z3 = self.zonaSin
                y0, y1, x0, x1 = max(0, z1), min(H, z3), max(0, z0), min(W, z2)
                c[y0:y1, x0:x1] = self.bufSin[y0:y1, x0:x1]
                g0, g1, g2, g3 = self.regalo
                yy0, yy1 = max(0, g1 - dy), min(H, g3 - dy)
                x0, x1 = max(0, g0), min(W, g2)
                if yy1 > yy0 and x1 > x0:
                    origen = buf[yy0 + dy:yy1 + dy, x0:x1]
                    rr, bb = origen[..., 0], origen[..., 2]
                    es_regalo = (bb < 100) & (rr > 120) & (rr - bb > 60)
                    zona = c[yy0:yy1, x0:x1]
                    zona[es_regalo] = origen[es_regalo]
        # botes: la zona se estira hacia arriba con la base fija (pies en el suelo) y vuelve; no deja huecos
        for (r0, r1, r2, r3), alt, per in self.botes:
            alto = float(r3 - r1)
            sc = 1 + alt / alto * self.pulso(t, per)
            if sc <= 1.001:
                continue
            y0, y1 = max(0, math.floor(r3 - alto * sc)), min(H, r3)
            x0, x1 = max(0, r0), min(W, r2)
            Ys = self.Y[y0:y1, x0:x1]
            sy = redondear(r3 - (r3 - Ys) / sc).astype(np.intp)
            dentro = (Ys >= r3 - alto * sc) & (sy >= r1) & (sy < r3)
            zona = c[y0:y1, x0:x1]
            Xi = np.broadcast_to(np.arange(x0, x1), Ys.shape)
            zona[dentro] = buf[sy[dentro], Xi[dentro]]
        # estrella del centro: se amplía desde su centro
        if self.radio > 0 and s > 1.001:
            R = self.radio * s
            y0, y1 = max(0, math.floor(self.CY - R)), min(H, math.ceil(self.CY + R) + 1)
            x0, x1 = max(0, math.floor(self.CX - R)), min(W, math.ceil(self.CX + R) + 1)
            Xs, Ys, ds = self.X[y0:y1, x0:x1], self.Y[y0:y1, x0:x1], self.d[y0:y1, x0:x1]
            dentro = ds < R
            sx = redondear(self.CX + (Xs - self.CX) / s).astype(np.intp)
            sy = redondear(self.CY + (Ys - self.CY) / s).astype(np.intp)
            al = np.clip((self.radio - ds / s) / 12, 0, 1)[dentro][:, None]
            zona = c[y0:y1, x0:x1]
            zona[dentro] = zona[dentro] * (1 - al) + buf[sy[dentro], sx[dentro]] * al
        return np.clip(redondear(c), 0, 255).astype(np.uint8)

    def fotogramas(self):
        for f in range(int(self.dur * self.fps)):
            yield self.fotograma(f)


def main(args):
    if len(args) != 3:
        sys.stderr.write(__doc__)
        return 64
    slide, ajustes, salida = args
    an = Animador(slide, ajustes)
    if salida == "--crudo":
        for fr in an.fotogramas():
            sys.stdout.buffer.write(fr.tobytes())
        return 0
    fps = an.fps if an.fps != int(an.fps) else int(an.fps)
    p = subprocess.Popen([ffmpeg(), "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{an.W}x{an.H}",
                          "-r", str(fps), "-i", "-", "-c:v", "libx264", "-preset", "slow", "-crf", "17", "-pix_fmt", "yuv420p",
                          "-an", "-movflags", "+faststart", salida], stdin=subprocess.PIPE)
    try:
        for fr in an.fotogramas():
            p.stdin.write(fr.tobytes())
    except BrokenPipeError:
        pass
    p.stdin.close()
    if p.wait() != 0:
        print(f"FALLO al hacer el vídeo {salida}", file=sys.stderr)
        return 1
    print(f"OK {salida}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""Deja la carpeta de datos lista la primera vez (lo usan los instaladores de Mac y de Windows).

    preparar_datos.py <carpeta_datos>

Crea el primer cliente igual que lo crea la app con «+ Nuevo cliente»:
  datos/perfiles/mi_marca/{marca/fotos, fichas, virales, salida}, marca/marca.txt y perfil.json
  datos/ajustes.json (perfil_activo) y datos/CUENTA_ACTUAL.txt
No toca nada que ya exista. Si los datos son del formato antiguo (un solo cliente, sin perfiles/), no hace nada:
la app los convierte sola la primera vez que se abre (motor/migrar_perfiles.py, con copia antes).
"""
import json
import os
import sys

# la misma plantilla que usa la app para un cliente nuevo (app/src/app/api/perfiles/route.ts)
MARCA_NUEVA = """handle: @tucuenta
azul: #1A79FB
angulo:
ropa: traje azul marino y camisa blanca, sin corbata
idioma: español. Se dice "AI", nunca "IA"
fotos:
tipografia:
tope_imagenes_dia: 60
"""
UBICACION = {"ciudad": "Newark", "estado": "New Jersey", "pais": "United States", "codigo": "US", "lat": 40.7357, "lon": -74.1724}


def escribir_si_falta(ruta, texto):
    if not os.path.exists(ruta):
        with open(ruta, "w", encoding="utf-8", newline="\n") as f:
            f.write(texto)


def main(datos):
    os.makedirs(datos, exist_ok=True)
    perfiles = os.path.join(datos, "perfiles")
    hay_perfiles = os.path.isdir(perfiles) and any(os.path.isdir(os.path.join(perfiles, d)) for d in os.listdir(perfiles))
    antiguos = any(os.path.exists(os.path.join(datos, d)) for d in ("marca", "fichas", "virales", "salida"))
    if not hay_perfiles and antiguos:
        print("Datos del formato antiguo: la app los pasa a clientes la primera vez que se abre (con copia antes).")
        return 0
    if not hay_perfiles:
        cliente = os.path.join(perfiles, "mi_marca")
        for sub in ("marca/fotos", "fichas", "virales", "salida"):
            os.makedirs(os.path.join(cliente, sub), exist_ok=True)
        escribir_si_falta(os.path.join(cliente, "marca", "marca.txt"), MARCA_NUEVA)
        escribir_si_falta(os.path.join(cliente, "perfil.json"), json.dumps({"nombre": "Mi marca", "ubicacion": UBICACION}, indent=2, ensure_ascii=False))
        escribir_si_falta(os.path.join(datos, "ajustes.json"), json.dumps({"perfil_activo": "mi_marca"}, indent=2))
        print("Primer cliente creado: datos/perfiles/mi_marca (se rellena en la bienvenida de la app).")
    else:
        print("Los datos ya tienen clientes: no se toca nada.")
    escribir_si_falta(os.path.join(datos, "CUENTA_ACTUAL.txt"), "cuenta1\n")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.stderr.write(__doc__)
        sys.exit(64)
    sys.exit(main(sys.argv[1]))

#!/usr/bin/env python3
"""Una generación a la vez y la app ve lo que hace Claude (lo usan los motores de Mac y de Windows).

  en_curso.py <datos> [estado_propio]
      Escribe el nombre del carrusel que tiene una generación o corrección en marcha, en cualquier cliente
      (sin contar estado_propio). No escribe nada si no hay ninguna. Codex hace una sola a la vez.
  en_curso.py --apuntar <archivo_estado> <pid> <orden> [args...]
      Escribe el estado «en_curso» que lee la app (el mismo que escribe ella al lanzar una orden).
"""
import datetime
import glob
import json
import os
import sys
import time


def vivo(pid):
    """¿Sigue en marcha el proceso? En Windows no se usa os.kill(pid, 0): allí 0 es Ctrl+C."""
    if os.name == "nt":
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        codigo = ctypes.c_ulong()
        ok = k.GetExitCodeProcess(h, ctypes.byref(codigo))
        k.CloseHandle(h)
        return bool(ok) and codigo.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def en_curso(datos, propio=""):
    propio = os.path.abspath(propio) if propio else ""
    estados = (glob.glob(os.path.join(datos, "perfiles", "*", "salida", "*", "_estado.json"))
               + glob.glob(os.path.join(datos, "salida", "*", "_estado.json")))
    for f in sorted(estados):
        if os.path.abspath(f) == propio or os.path.exists(f + ".fin"):
            continue
        try:
            with open(f, encoding="utf-8") as h:
                e = json.load(h)
        except Exception:
            continue
        if e.get("estado") != "en_curso":
            continue
        pid = e.get("pid")
        if isinstance(pid, int):
            if not vivo(pid):
                continue
        else:  # estados antiguos sin pid: 40 minutos de margen, como la app
            try:
                inicio = datetime.datetime.fromisoformat(str(e.get("inicio", "")).replace("Z", "+00:00")).timestamp()
            except ValueError:
                continue
            if time.time() - inicio > 40 * 60:
                continue
        return os.path.basename(os.path.dirname(f))
    return ""


def apuntar(archivo, pid, orden):
    ahora = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with open(archivo, "w", encoding="utf-8") as h:
        json.dump({"estado": "en_curso", "orden": orden, "inicio": ahora, "salida": "", "pid": pid, "lanzada_por": "claude"}, h)


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "--apuntar":
        apuntar(a[1], int(a[2]), a[3:])
    elif a:
        n = en_curso(a[0], a[1] if len(a) > 1 else "")
        if n:
            print(n)
    else:
        sys.stderr.write(__doc__)
        sys.exit(64)

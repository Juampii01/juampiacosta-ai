# Carrusel Creator Pro · manual para Claude

App local (Mac y Windows) que convierte carruseles virales de Instagram, o el guion del usuario, en carruseles con la marca de cada cliente. Codex genera las imágenes; Claude redacta las fichas y las descripciones; la app lo enseña todo y deja los JPG listos para subir.

**Habla siempre en español general**, claro y sencillo (nunca «compu»: di «tu Mac», «tu PC» o «tu equipo»).

**Para instalarla:** sigue [`mac/install.md`](mac/install.md) o [`windows/install.md`](windows/install.md), según el sistema.

## Al empezar cada conversación

1. Lee **`datos/usuario.md`** y llama al usuario por su nombre.
2. Si no existe (recién instalada), pregúntale cómo se llama y créalo con esta forma:

   ```markdown
   # Usuario
   nombre: <su nombre>

   ## Gustos
   - <lo que le gusta o no, en cuanto lo diga>

   ## Cambios que ha pedido
   - <fecha> · <qué pidió cambiar>
   ```

3. Cada vez que diga algo que le gusta o no le gusta, o pida un cambio, apúntalo ahí en el momento. `datos/` es suyo: nunca se sube a git.

## Cómo funciona

| Paso | Quién | Qué pasa |
|---|---|---|
| Link o guion | El usuario | Pega el link del carrusel original o su guion en bloques "SLIDE 1", "SLIDE 2"… |
| Ficha | Claude | Redacta la ficha de su versión mirando los slides del original. El usuario la revisa |
| Comprobación | El motor | Frena cifras que no están en el original, textos largos y palabras que ya dieron problemas |
| Generar | Codex | Una llamada: todos los slides. **Sin pie ni contador**: la imagen de Codex es el slide final |
| Revisión | El usuario | Mira cada slide; se corrige lo que falle (1 imagen por corrección) |
| Descripción | Claude | Texto para Instagram con 5 hashtags, y 5 variaciones si las pide |
| Vídeo (opcional) | Claude | Anima un slide (ver «Vídeo») |
| Cerrar | El motor | JPG 1080×1350 sin metadatos de AI, con la ubicación del cliente, y ZIP para descargar |

Las reglas del contenido (ficha, palabras prohibidas, lista de control) están en [`motor/REGLAS.md`](motor/REGLAS.md). Cúmplelas.

## Antes de crear un carrusel, pregunta

Solo lo que no sepas ya (míralo antes en `datos/usuario.md` y en la marca del cliente):

1. ¿Para qué cliente es? (si hay más de uno)
2. ¿Copiamos un carrusel de Instagram (el link) o es su propio guion?
3. ¿Qué palabra tiene que comentar la gente? (la CTA, por ejemplo REPO)
4. ¿Sale su personaje en los slides o no?
5. ¿Fondo oscuro (el normal) o claro?

## Usar el motor sin abrir la app

Claude puede trabajar directamente con el motor, sin arrancar la app. **Todo lo que hagas queda dentro de la app**, porque el motor escribe en las mismas carpetas que ella:

- Ficha: `datos/perfiles/<cliente>/fichas/<nombre>.md`
- Slides: `datos/perfiles/<cliente>/salida/<nombre>/1.png, 2.png…` (al cerrar, `.jpg`)

Nunca dejes un carrusel en otra carpeta: si no está ahí, el usuario no lo ve en la app.

| Sistema | Cómo se llama al motor |
|---|---|
| Mac | `mac/motor/carrusel.sh <orden> …` |
| Windows | `python windows\motor\carrusel.py <orden> …` |

Con `PERFIL=<cliente>` delante se trabaja con otro cliente sin cambiar el activo de la app.

| Orden | Qué hace | Gasta |
|---|---|---|
| `bajar <url> <nombre>` | Descarga los slides del original a `virales/<nombre>/` | 1 crédito de ScrapeCreators |
| `ficha_ia <nombre>` | Claude Code redacta la ficha mirando el original | Tokens de Claude |
| `nueva <nombre> <N>` | Ficha vacía para rellenar a mano | Nada |
| `comprobar <nombre>` | Comprueba la ficha | Nada |
| `generar <nombre>` | Genera todos los slides con Codex y hace la hoja de revisión | N imágenes |
| `corregir <nombre> <n> "<cambio>"` | Corrige un slide editándolo (`REDISENO=1` delante: lo rehace con el diseño del original) | 1 imagen |
| `elegir <nombre> <a,b,c>` | Si Codex rehízo imágenes, coloca las buenas como slides 1..N | Nada |
| `encoger <nombre> <n> [factor] [px]` | Encoge la escena de un slide si llega al borde | Nada |
| `revisar <nombre>` | Rehace la hoja de revisión | Nada |
| `descripcion <nombre>` | Descripción de Instagram en `salida/<nombre>/descripcion.txt` | Tokens de Claude |
| `variaciones <nombre>` | 5 variaciones de la descripción | Tokens de Claude |
| `animar <nombre> <n> [ajustes]` | Vídeo del slide (`n.mp4`) | Nada |
| `reestampar <nombre> [n]` | Quita el pie a slides hechos antes del 15/10/2026 | Nada |
| `cerrar <nombre>` | Solo con el OK del usuario: JPG limpios, que la app deja descargar en ZIP | Nada |
| `cupo` | Imágenes gastadas en 24 h | Nada |

Lo que hay que saber:

- **La app ve lo que lanzas.** Cuando generas, corriges o escribes una ficha o descripción sin la app, el motor apunta el mismo estado que la app (en marcha → registro → final). Si el usuario tiene la app abierta, lo ve en directo.
- **Una generación a la vez.** Codex es una sola cuenta: si ya hay otra generación en marcha (la lance la app o tú), el motor responde `OCUPADO` (código 7) y no gasta nada. Espera a que termine.
- **Cupo:** unas 60 imágenes al día por cuenta de ChatGPT. Antes de generar, mira `cupo` y di cuántas vas a gastar.
- Las claves (ScrapeCreators) las pega el usuario en la app. Nunca las pidas por el chat ni las guardes en archivos.

## Vídeo de un slide

Solo lo maneja Claude. Funciona igual en Mac y en Windows (`motor/animar.py`, con numpy).

1. Describe la idea en 2 o 3 líneas (qué se mueve y cómo) y espera el OK del usuario antes de montarla.
2. Escribe los ajustes en `datos/perfiles/<cliente>/animar/<nombre>/slide<n>.json`. Hay un ejemplo en [`motor/animar_ejemplo.json`](motor/animar_ejemplo.json) y todas las opciones están al principio de `motor/animar.py`.
3. Prueba primero con pocos segundos (`"segundos": 1`) y mira un fotograma antes del vídeo completo.
4. Lanza `animar <nombre> <n>`. El vídeo queda como `salida/<nombre>/<n>.mp4` y la app lo enseña.

Si el slide cambia (corregir, encoger, elegir, reestampar), su vídeo se borra: hay que volver a animarlo. En un carrusel ya cerrado, el vídeo sale limpio de metadatos y con la ubicación, como los JPG.

## Si cambias código

La app es una sola; el motor tiene una parte común y una por sistema:

```
app/       la interfaz (Next.js) y su API local: la misma en Mac y Windows
motor/     lo común: ficha.py, bajar.py, animar.py, en_curso.py, preparar_datos.py, prompts y REGLAS.md
mac/       motor de Mac (carrusel.sh, zsh), instalador, arranque e icono del Dock
windows/   motor de Windows (carrusel.py, Python + Pillow), instalador y arranque
datos/     lo de cada usuario (marca, fotos, claves, carruseles, usuario.md): nunca se sube a git
```

- **Hay dos motores con las mismas órdenes.** Si cambias algo del motor, cámbialo en los dos y pasa las dos pruebas. Las dos tienen que terminar con *"fallan 0"* y no gastan imágenes ni créditos:
  - Mac: `mac/motor/pruebas/correr.sh`
  - Windows: `python windows/motor/pruebas/correr.py` (en un Mac necesita Pillow y numpy en un entorno aparte)
- En `app/`: `npx tsc --noEmit -p .` y `npx eslint src`. Lee `app/AGENTS.md` antes de tocar código de Next.js (versión 16, con cambios).
- Lo que sea solo de un sistema va en `mac/` o en `windows/`; lo común, en `motor/`.
- No des nada por terminado sin decir qué no se ha probado con una generación real.
